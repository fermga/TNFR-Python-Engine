"""Regional observations of supplied complete conservative sine enclosures.

The reader checks the declared law, chain and primitive interval evidence,
including recomputed Picard inclusion. It does not replay Taylor endpoint
proofs or authenticate a producer. All conclusions are conditional on the
supplied numerical endpoint enclosures, retaining their full uncertainty.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from fractions import Fraction as Q

from .._exact_time import exact_or_represented_real
from ..mathematics._rational_interval import INTERVAL_METHOD, I, cos, pi_interval, sin
from ..mathematics._validated_taylor import ValidatedTaylorStep
from ._sine_admission import _sine_model_coefficients
from .relational_observations import _ordered
from .relational_sine_comparison import SineRegionalChannelBalance
from .relational_sine_forecast import SineForecast, _admit_support, _sine_flow

__all__ = (
    "SineRegionalOrganizationStep",
    "SineRegionalOrganization",
    "assess_sine_regional_organization",
    "SineRegionalChannelStep",
    "SineRegionalChannelHistory",
    "assess_sine_regional_channels",
)


def _scalar(value, label):
    return exact_or_represented_real(value, label)


def _interval(value, label):
    if isinstance(value, I):
        return I(_scalar(value.lo, label), _scalar(value.hi, label))
    return I(_scalar(value, label))


def _interval_row(values, size, label):
    values = _ordered(values, label, limit=size + 1)
    if len(values) != size:
        raise ValueError(f"{label} must retain every full-state coordinate")
    return tuple(_interval(value, f"{label}[{i}]") for i, value in enumerate(values))


def _unit_box(values, size, label, *, point_capacity=False):
    values = _interval_row(values, size, label)
    if not values[-1].contains(1) or point_capacity and values[-1] != I(1):
        raise ValueError(f"{label} must retain the held unit capacity")
    return values


def _flow(box, forecast):
    return _sine_flow(
        box,
        neighbors=forecast.neighbors,
        visible_capacity=forecast.visible_capacity,
        model=forecast.model,
    )


def _admit_forecast(forecast):
    if not isinstance(forecast, SineForecast):
        raise TypeError("an exact SineForecast is required")
    if _sine_model_coefficients(forecast.model) != (0, 1, 1):
        raise ValueError(
            "regional organization requires zero loss and unit exchange and beta"
        )
    neighbors, capacity = _admit_support(
        forecast.neighbors, forecast.visible_capacity, forecast.model
    )
    if any(value != 1 for value in capacity):
        raise ValueError("regional organization requires held unit capacities")
    if forecast.freeze_hidden is not False:
        raise ValueError("changed-capacity frozen forecasts are unsupported")
    if forecast.method != "full_sine_held_capacity_Picard_Taylor_Metzler128_v1":
        raise ValueError("the declared complete sine forecast method is required")
    size = 2 * len(neighbors) + 1
    initial = _unit_box(forecast.initial_box, size, "initial_box", point_capacity=True)
    endpoint = _unit_box(forecast.endpoint, size, "endpoint", point_capacity=True)
    at, end, actual, step_size = (
        _scalar(getattr(forecast, name), name)
        for name in ("observation_time", "end_time", "validated_end_time", "time_step")
    )
    if not 0 <= at <= actual <= end or at == end or step_size <= 0:
        raise ValueError("forecast times must retain their ordered positive horizon")
    if (end - at) / step_size > 256:
        raise ValueError("forecast must respect the shared 256-step budget")
    if type(forecast.order) is not int or not 1 <= forecast.order <= 16:
        raise ValueError("forecast Taylor order must lie between 1 and 16")
    reasons = _ordered(forecast.reasons, "reasons")
    if any(not isinstance(value, str) or not value for value in reasons):
        raise ValueError("forecast reasons must be nonempty strings")
    complete = actual == end
    if forecast.status not in ("admitted", "unavailable"):
        raise ValueError("unknown forecast status")
    if (forecast.status == "admitted") != complete or bool(reasons) == complete:
        raise ValueError("forecast status and reasons must match actual coverage")
    failed = (
        None
        if forecast.failed_tube is None
        else _unit_box(forecast.failed_tube, size, "failed_tube")
    )
    if complete and failed is not None:
        raise ValueError("a complete forecast cannot retain a failed tube")
    start = forecast.forecast_start
    if start is not None:
        start = _scalar(start, "forecast_start")
        if not at <= start <= end:
            raise ValueError("forecast_start must lie in the declared horizon")
    normalized = replace(
        forecast,
        neighbors=neighbors,
        visible_capacity=capacity,
        initial_box=initial,
        endpoint=endpoint,
        observation_time=at,
        end_time=end,
        validated_end_time=actual,
        time_step=step_size,
        reasons=reasons,
        failed_tube=failed,
        forecast_start=start,
    )
    time, incoming, steps = at, initial, []
    raw_steps = _ordered(forecast.steps, "steps", limit=257)
    if len(raw_steps) > 256:
        raise ValueError("forecast exceeds the shared step budget")
    for index, step in enumerate(raw_steps):
        if not isinstance(step, ValidatedTaylorStep):
            raise TypeError("forecast steps must be ValidatedTaylorStep reports")
        step_time = _scalar(step.time, "step.time")
        duration = _scalar(step.duration, "step.duration")
        if step_time != time or duration <= 0 or duration != min(step_size, end - time):
            raise ValueError(
                "forecast steps must retain the contiguous declared time grid"
            )
        if time + duration > actual:
            raise ValueError("a step extends beyond the validated endpoint time")
        tube = _unit_box(step.tube, size, "step.tube")
        final = _unit_box(step.endpoint, size, "step.endpoint", point_capacity=True)
        if any(not value.subset_of(bound) for value, bound in zip(incoming, tube)):
            raise ValueError("incoming endpoint must lie in the next whole-time tube")
        if any(not value.subset_of(bound) for value, bound in zip(final, tube)):
            raise ValueError("step endpoint must lie in its whole-time tube")
        margin = _scalar(step.picard_interior_margin, "step.picard_interior_margin")
        domain = tuple(
            _scalar(value, "step.domain_lower_bounds")
            for value in _ordered(step.domain_lower_bounds, "step.domain_lower_bounds")
        )
        if margin <= 0 or not domain or min(domain) <= 0:
            raise ValueError("step Picard and domain margins must be strictly positive")
        radii = _ordered(
            step.propagated_initial_radii,
            "step.propagated_initial_radii",
            limit=size + 1,
        )
        if len(radii) != size:
            raise ValueError("propagated radii must retain every state coordinate")
        radii = tuple(
            _scalar(value, "step.propagated_initial_radii") for value in radii
        )
        if any(value < 0 for value in radii):
            raise ValueError("propagated radii must be nonnegative")
        remainder = _interval_row(
            step.local_remainder_bounds, size, "step.local_remainder_bounds"
        )
        # This cheap check proves inclusion of the declared tube from the
        # supplied incoming endpoint set. It does not revalidate that incoming
        # Taylor endpoint's derivation, which remains a numerical premise.
        rates = _flow(tube, normalized)
        images = tuple(
            value + I(0, duration) * rate for value, rate in zip(incoming, rates)
        )
        recomputed = min(
            min(image.lo - bound.lo, bound.hi - image.hi)
            for image, bound in zip(images, tube)
        )
        if recomputed <= 0 or margin > recomputed:
            raise ValueError("step does not retain its claimed strict Picard inclusion")
        steps.append(
            replace(
                step,
                time=step_time,
                duration=duration,
                tube=tube,
                endpoint=final,
                picard_interior_margin=margin,
                domain_lower_bounds=domain,
                propagated_initial_radii=radii,
                local_remainder_bounds=remainder,
            )
        )
        time, incoming = time + duration, final
    if time != actual or incoming != endpoint:
        raise ValueError(
            "forecast endpoint and validated time must match the complete step chain"
        )
    return replace(normalized, steps=tuple(steps))


def _cycle(forecast, cycle_indices):
    cycle = _ordered(cycle_indices, "cycle_indices", limit=6)
    size = len(forecast.neighbors)
    if (
        len(cycle) != 5
        or any(type(i) is not int or not 0 <= i < size for i in cycle)
        or len(set(cycle)) != 5
    ):
        raise ValueError(
            "cycle_indices must contain five distinct full-source node indices"
        )
    pairs = tuple(zip(cycle, cycle[1:] + cycle[:1]))
    expected = {frozenset(pair) for pair in pairs}
    members = set(cycle)
    actual = {
        frozenset((i, j)) for i in cycle for j in forecast.neighbors[i] if j in members
    }
    if expected != actual:
        raise ValueError("the receiver must be an induced C5 in the full support")
    return cycle


def _branches(gaps):
    pi = pi_interval()
    offsets, principal = [], []
    for gap in gaps:
        candidate = (gap + pi) / (2 * pi)
        left, right = candidate.lo // 1, candidate.hi // 1
        if left != right:
            return None, None, None, None
        shifted = gap - 2 * left * pi
        if shifted.abs_max >= pi.lo:
            return None, None, None, None
        offsets.append(left)
        principal.append(shifted)
    principal = tuple(principal)
    margin = min(pi.lo / 2 - gap.abs_max for gap in principal)
    return tuple(offsets), principal, -sum(offsets), margin


def _snapshot(box, forecast, cycle):
    size = len(forecast.neighbors)
    forms, phases = box[:size], box[size : 2 * size]
    members = set(cycle)
    regional_form, regional_phase, full = I(0), I(0), I(0)
    # The actual held capacity is exactly1 even where a whole-time Picard
    # tube includes additional artificial values in that augmented coordinate.
    rates = _flow(box[:-1] + (I(1),), forecast)
    boundary_power = I(0)
    for i, row in enumerate(forecast.neighbors):
        for j in row:
            if i >= j:
                continue
            form = (forms[j] - forms[i]) ** 2 / 2
            phase = 1 - cos(phases[j] - phases[i])
            full += form + phase
            if i in members and j in members:
                regional_form += form
                regional_phase += phase
            elif (i in members) != (j in members):
                inside, outside = (i, j) if i in members else (j, i)
                boundary_power += (forms[outside] - forms[inside]) * rates[
                    inside
                ] + sin(phases[outside] - phases[inside]) * rates[size + inside]
    anchor = cycle[0]
    relative_rates = tuple(
        I(0) if i == anchor else rates[size + i] - rates[size + anchor]
        for i in range(size)
    )
    return (
        regional_form,
        regional_phase,
        regional_form + regional_phase,
        full,
        relative_rates,
        boundary_power,
        rates[size : 2 * size],
    )


@dataclass(frozen=True)
class SineRegionalChannelStep:
    """Whole-time storage rates and cumulative integrals at the step endpoint."""

    time: Q
    duration: Q
    channels: SineRegionalChannelBalance
    cumulative_internal_conversion: I
    cumulative_boundary_form_input: I
    cumulative_boundary_phase_input: I
    form_storage_change: I
    phase_storage_change: I
    form_integral_residual: I
    phase_integral_residual: I
    phase_storage_upper_bound: Q
    running_phase_work_upper_bound: Q


@dataclass(frozen=True)
class SineRegionalChannelHistory:
    """Retrospective or prospective conditional analysis of supplied enclosures."""

    forecast: SineForecast
    cycle_indices: tuple[int, ...]
    initial_form_storage: I
    initial_phase_storage: I
    endpoint_form_storage: I
    endpoint_phase_storage: I
    steps: tuple[SineRegionalChannelStep, ...]
    cumulative_internal_conversion: I
    cumulative_boundary_form_input: I
    cumulative_boundary_phase_input: I
    phase_storage_upper_bound: Q
    running_phase_work_upper_bound: Q
    initial_phase_flat_certified: bool
    acute_accessibility_barrier: Q
    acute_entry_excluded_on_validated_prefix: bool
    horizon_complete: bool
    clock: str = "structural_t"
    arithmetic_method: str = INTERVAL_METHOD
    scope: tuple[str, ...] = (
        "same_complete_conservative_sine_law_and_unit_held_capacity",
        "shared_regional_storage_channel_kernel_original_structural_t",
        "positive_internal_conversion_transfers_phase_storage_to_form_storage",
        "boundary_storage_inputs_are_not_conjugate_boundary_work_components",
        "cumulative_bounds_integrate_whole_time_rates_not_endpoint_samples",
        "primitive_forecast_readmitted_and_Picard_inclusion_recomputed",
        "Taylor_endpoint_enclosures_remain_supplied_premises_no_replay_or_authentication",
        "phase_flat_admission_requires_equal_exact_represented_lifts",
        "C5_phase_minimax_excludes_acute_unit_winding_entry_below_7_over_2",
        "barrier_is_necessary_running_phase_storage_not_sufficient_entry_or_arbitrary_winding",
        "partial_prefix_does_not_certify_unreached_horizon",
        "no_source_selection_damping_new_trajectory_or_physical_identification",
    )

    def to_dict(self):
        from ..sdk.relational_reports import _project

        return {
            "schema": "tnfr.sine-regional-channel-history.v1",
            "report": _project(self),
        }


def assess_sine_regional_channels(forecast, *, cycle_indices):
    """Integrate signed channel bounds without rerunning the supplied forecast.

    The same strict complete-law and endpoint-evidence admission used by the
    regional organization observer applies. The C5 minimax conclusion requires
    exactly flat initial receiver phase; inability to certify flatness is not
    a claim that phase is nonflat. The barrier concerns reaching any fully
    acute unit-winding state, not arbitrary transient winding.
    """
    from .relational_sine_comparison import _sine_regional_channel_balance

    forecast = _admit_forecast(forecast)
    cycle = _cycle(forecast, cycle_indices)
    size = len(forecast.neighbors)
    edges = tuple(
        (i, j) for i, row in enumerate(forecast.neighbors) for j in row if i < j
    )
    degrees = tuple(len(row) for row in forecast.neighbors)
    initial = _snapshot(forecast.initial_box, forecast, cycle)
    endpoint = _snapshot(forecast.endpoint, forecast, cycle)
    initial_phase = tuple(forecast.initial_box[size + i] for i in cycle)
    flat = all(
        value == initial_phase[0] and value.width == 0 for value in initial_phase
    )
    conversion, boundary_form, boundary_phase = I(0), I(0), I(0)
    phase_upper = initial[1].hi
    running_phase_work_upper = Q(0)
    steps = []
    for step in forecast.steps:
        channels = _sine_regional_channel_balance(
            reference_model=forecast.model,
            edges=edges,
            degrees=degrees,
            capacity=(Q(1),) * size,
            epi=step.tube[:size],
            phase=step.tube[size : 2 * size],
            region_indices=cycle,
        )
        phase_work_tube = (
            -conversion
            + boundary_phase
            + I(0, step.duration)
            * (-channels.internal_conversion + channels.boundary_phase_input)
        )
        running_phase_work_upper = max(running_phase_work_upper, phase_work_tube.hi)
        conversion += step.duration * channels.internal_conversion
        boundary_form += step.duration * channels.boundary_form_input
        boundary_phase += step.duration * channels.boundary_phase_input
        end = _snapshot(step.endpoint, forecast, cycle)
        tube = _snapshot(step.tube, forecast, cycle)
        form_change, phase_change = end[0] - initial[0], end[1] - initial[1]
        form_residual = form_change - (conversion + boundary_form)
        phase_residual = phase_change - (-conversion + boundary_phase)
        if not form_residual.contains(0) or not phase_residual.contains(0):
            raise ValueError("endpoint storage contradicts integrated channel bounds")
        phase_upper = max(phase_upper, tube[1].hi)
        steps.append(
            SineRegionalChannelStep(
                time=step.time,
                duration=step.duration,
                channels=channels,
                cumulative_internal_conversion=conversion,
                cumulative_boundary_form_input=boundary_form,
                cumulative_boundary_phase_input=boundary_phase,
                form_storage_change=form_change,
                phase_storage_change=phase_change,
                form_integral_residual=form_residual,
                phase_integral_residual=phase_residual,
                phase_storage_upper_bound=tube[1].hi,
                running_phase_work_upper_bound=running_phase_work_upper,
            )
        )
    barrier = Q(7, 2)
    return SineRegionalChannelHistory(
        forecast=forecast,
        cycle_indices=cycle,
        initial_form_storage=initial[0],
        initial_phase_storage=initial[1],
        endpoint_form_storage=endpoint[0],
        endpoint_phase_storage=endpoint[1],
        steps=tuple(steps),
        cumulative_internal_conversion=conversion,
        cumulative_boundary_form_input=boundary_form,
        cumulative_boundary_phase_input=boundary_phase,
        phase_storage_upper_bound=phase_upper,
        running_phase_work_upper_bound=running_phase_work_upper,
        initial_phase_flat_certified=flat,
        acute_accessibility_barrier=barrier,
        acute_entry_excluded_on_validated_prefix=flat
        and min(phase_upper, initial[1].hi + running_phase_work_upper) < barrier,
        horizon_complete=forecast.validated_end_time == forecast.end_time,
    )


@dataclass(frozen=True)
class SineRegionalOrganizationStep:
    """Regional properties holding throughout one supplied Picard tube."""

    time: Q
    duration: Q
    cycle_raw_gap_bounds: tuple[I, ...]
    cycle_principal_gap_bounds: tuple[I, ...] | None
    edge_turn_offsets: tuple[int, ...] | None
    winding: int | None
    acute_margin_lower_bound: Q | None
    requested_acute_margin_met: bool
    acute_winding_excluded: bool
    exclusion_reasons: tuple[str, ...]
    regional_form_storage: I
    regional_phase_storage: I
    regional_storage: I
    integrated_regional_work: I
    full_storage: I
    relative_phase_rate_bounds: tuple[I, ...]
    phase_rate_bounds: tuple[I, ...]
    regional_boundary_work: I


@dataclass(frozen=True)
class SineRegionalOrganization:
    """Conditional whole-time regional assessment without endpoint proof replay."""

    forecast: SineForecast
    cycle_indices: tuple[int, ...]
    minimum_duration: Q
    acute_margin: Q
    initial_regional_storage: I
    endpoint_regional_storage: I
    endpoint_integrated_regional_work: I
    initial_full_storage: I
    endpoint_full_storage: I
    steps: tuple[SineRegionalOrganizationStep, ...]
    certified_windows: tuple[tuple[Q, Q], ...]
    horizon_complete: bool
    outcome: str
    unresolved: tuple[str, ...]
    clock: str = "structural_t"
    arithmetic_method: str = INTERVAL_METHOD
    scope: tuple[str, ...] = (
        "complete_conservative_sine_law_original_structural_t_clock",
        "fixed_full_support_and_exact_unit_held_capacity",
        "induced_receiver_C5_and_all_environmental_coordinates_retained",
        "source_chain_scalars_and_boxes_readmitted_with_recomputed_Picard_inclusion",
        "conditional_on_supplied_Taylor_endpoint_enclosures_no_solver_replay_or_authentication",
        "all_regional_fields_rebuilt_from_complete_boxes_without_midpoint_replacement",
        "known_held_unit_capacity_tightens_artificial_Picard_capacity_width",
        "whole_time_fixed_branch_winding_uses_exact_telescoping_not_rounded_samples",
        "requested_margin_and_duration_are_observation_policies_not_physical_absence",
        "edge_cosine_two_hop_cosine_and_zero_winding_are_sufficient_exclusions",
        "integrated_net_boundary_work_equals_internal_storage_change_by_exact_zero_loss_balance",
        "regional_boundary_work_is_instantaneous_power_not_integrated_work",
        "partial_horizon_remains_explicitly_unresolved_without_extrapolation",
        "finite_retention_does_not_establish_initially_unorganized_preparation_capture_or_identity",
        "no_forcing_support_events_constitutive_selection_or_physical_identification",
    )

    def to_dict(self):
        from ..sdk.relational_reports import _project

        return {
            "schema": "tnfr.sine-regional-organization.v1",
            "report": _project(self),
        }


def assess_sine_regional_organization(
    forecast, *, cycle_indices, minimum_duration, acute_margin
) -> SineRegionalOrganization:
    """Observe finite acute C5 winding or sufficient absence on supplied tubes.

    ``minimum_duration`` is strictly positive in the forecast's original t
    clock. ``acute_margin`` is a nonnegative requested margin in radians.
    Failing either requested criterion does not prove acute winding absent.
    Returned work is net inward boundary work since the initial observation,
    obtained from the same model's exact conservative regional energy identity.
    """
    forecast = _admit_forecast(forecast)
    cycle = _cycle(forecast, cycle_indices)
    minimum = _scalar(minimum_duration, "minimum_duration")
    margin = _scalar(acute_margin, "acute_margin")
    if minimum <= 0 or margin < 0:
        raise ValueError(
            "minimum_duration must be positive and acute_margin nonnegative"
        )
    size = len(forecast.neighbors)
    initial = _snapshot(forecast.initial_box, forecast, cycle)
    endpoint = _snapshot(forecast.endpoint, forecast, cycle)
    observations, windows = [], []
    run_start, run_end, run_offsets = None, None, None

    def finish_run():
        if run_start is not None and run_end - run_start >= minimum:
            windows.append((run_start, run_end))

    for step in forecast.steps:
        phases = step.tube[size : 2 * size]
        gaps = tuple(
            phases[j] - phases[i] for i, j in zip(cycle, cycle[1:] + cycle[:1])
        )
        offsets, principal, winding, lower = _branches(gaps)
        reasons = []
        if any(cos(gap).hi <= 0 for gap in gaps):
            reasons.append("cycle_edge_nonpositive_cosine")
        if any(
            cos(phases[cycle[(i + 2) % 5]] - phases[cycle[i]]).lo >= 0 for i in range(5)
        ):
            reasons.append("two_hop_pair_nonnegative_cosine")
        if winding == 0:
            reasons.append("fixed_branch_zero_winding")
        meets = winding in (-1, 1) and lower is not None and lower > margin
        if meets:
            if run_start is None or run_offsets != offsets:
                finish_run()
                run_start, run_offsets = step.time, offsets
            run_end = step.time + step.duration
        else:
            finish_run()
            run_start, run_end, run_offsets = None, None, None
        form, phase, storage, full, relative, power, rates = _snapshot(
            step.tube, forecast, cycle
        )
        observations.append(
            SineRegionalOrganizationStep(
                step.time,
                step.duration,
                gaps,
                principal,
                offsets,
                winding,
                lower,
                meets,
                bool(reasons),
                tuple(reasons),
                form,
                phase,
                storage,
                storage - initial[2],
                full,
                relative,
                rates,
                power,
            )
        )
    finish_run()
    complete = forecast.validated_end_time == forecast.end_time
    if windows:
        outcome = "finite_acute_retention_certified"
    elif (
        complete
        and observations
        and all(step.acute_winding_excluded for step in observations)
    ):
        outcome = "acute_winding_excluded_on_horizon"
    else:
        outcome = "unresolved"
    unresolved = []
    if not complete:
        unresolved.append("requested_horizon_not_fully_enclosed")
    if outcome == "unresolved":
        unresolved.append("no_requested_window_or_complete_acute_absence_certificate")
    return SineRegionalOrganization(
        forecast=forecast,
        cycle_indices=cycle,
        minimum_duration=minimum,
        acute_margin=margin,
        initial_regional_storage=initial[2],
        endpoint_regional_storage=endpoint[2],
        endpoint_integrated_regional_work=endpoint[2] - initial[2],
        initial_full_storage=initial[3],
        endpoint_full_storage=endpoint[3],
        steps=tuple(observations),
        certified_windows=tuple(windows),
        horizon_complete=complete,
        outcome=outcome,
        unresolved=tuple(unresolved),
    )

"""Freeze, then execute one parent SHA closure without any continued trajectory."""

from __future__ import annotations

import platform
import subprocess
import sys
import traceback
from datetime import datetime, timezone
from fractions import Fraction as Q
from importlib.metadata import version
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(r"C:\TNFR-Python-Engine")
sys.path.insert(0, str(ROOT / "src"))

from tnfr.research.artifact_io import (
    decode_exact_tree,
    encode_exact_tree,
    file_receipt,
    read_bytes_bounded,
    sha256_bytes,
    validate_artifact_path,
    verify_archive_members,
    write_json_once,
)
from tnfr.research.local_capacity_history import encode_result, TIMES
from tnfr.research.maintained_parent_sha import predict_parent_sha
from tnfr.research.maintained_parent_sha_execution import EVENT_TIMESTAMP
from tnfr.research.maintained_parent_sha_source import load_um_successor
from tnfr.research.maintained_parent_thol import _signature
from tnfr.research.retained_graph_state import (
    record_graph_state,
    restore_recorded_graph_state,
)
from tnfr.utils.io import json_dumps, json_loads

OUT = ROOT / "docs/assets/maintained_parent_sha"
UM = ROOT / "docs/assets/maintained_parent_um_corrected"


def read(path):
    return decode_exact_tree(
        json_loads(read_bytes_bounded(path, max_bytes=32 * 1024**2))
    )


def write(name, value):
    write_json_once(OUT / name, encode_result(value))


def same(left, right):
    return json_dumps(
        encode_exact_tree(encode_result(left)), sort_keys=True
    ) == json_dumps(encode_exact_tree(encode_result(right)), sort_keys=True)


def receipt(path, label=None):
    return file_receipt(path, label=label or path.relative_to(ROOT).as_posix())


def verify(base, rows):
    for row in rows:
        name = validate_artifact_path(row["path"])
        path = (base / name).resolve()
        if not path.is_relative_to(base.resolve()) or receipt(path, name) != row:
            raise ValueError(f"frozen artifact differs: {name}")


def source():
    return load_um_successor(UM, repository_root=ROOT)


def freeze():
    admitted = source()
    prediction = predict_parent_sha(admitted)
    if prediction.capacity_absolute_error > Q(1, 2**40):
        raise ValueError("the declared binary64 capacity product misses its budget")
    OUT.mkdir(parents=True, exist_ok=False)
    write(
        "protocol.json",
        {
            "schema": "tnfr.maintained-parent-sha-protocol.v1",
            "evaluation_status_at_freeze": "not_evaluated",
            "question": "Does one canonical default parent SHA close the retained VAL,THOL,UM prefix and admit its capacity-changed complete law?",
            "source": "actual committed corrected UM response, with original25/27 and separate27/27 review, rebuilt from primitive THOL and UM evidence",
            "selection": "SHA is one U1b closure control, selected to isolate capacity effects; OZ, NAV and REMESH are distinct closure mechanisms with independent live admission.",
            "target_order": (2,),
            "seed": 17,
            "word_context": ("VAL", "THOL", "UM", "SHA"),
            "step_index": 3,
            "operation": "one shared atomic Silence stage; actual resolved defaults; strict live gates and grammar rejection by raising",
            "factor": prediction.factor,
            "structural_time": TIMES[-1],
            "event_metadata_timestamp": EVENT_TIMESTAMP,
            "clock": "zero-duration hybrid event; unchanged structural time; latency timestamp is wall-clock metadata",
            "maximum_events": 1,
            "maximum_attempts": 1,
            "maximum_trajectories": 0,
            "numerics": "binary64 canonical event with exact represented scalar product and independently rebuilt rational interval complete rows",
            "capacity_error_allowance": Q(1, 2**40),
            "pressure_refresh_error_allowance": Q(1, 2**46),
            "law": "x_dot=M*S(theta); theta_dot=M*L_W*x; M=diag(nu/(pi*d)); held positive post-SHA capacities, support and conductances; no Gamma or loss",
            "pressure": "stored raw pressure unchanged by SHA; separate shared bare-neighbor sine refresh with pressure-only boundary",
            "acceptance": (
                "freshly re-admitted UM source and exactly one canonical parent SHA stage",
                "all21 nodes,53 edge payloads,forms,phase lifts,node/neighbor order unchanged",
                "only parent capacity changes to the represented default product, with absolute exact-ideal error <=2^-40",
                "raw pressure preserved; shared refresh pressure-only with independent error <=2^-46",
                "full before/after laws rebuilt, exact zero event storage jump from unchanged primitive arguments",
                "actual parent history VAL,THOL,UM,SHA, zero debt and exact latency metadata; preserved hierarchy/temporal samples and no child baseline",
                "unchanged structural clock and declared lifecycle, alias-maxima and final stage metadata",
            ),
            "scope": "One supplied SHA closure. No automatic post-SHA motion certificate, frozen dynamics from latency, universal preferred closure, autonomous occurrence, reservoir or physical identification.",
            "stop": "retain one positive, negative or unavailable response; no retries, changed factors, weakened budget, IL intervention or regenerated motion",
        },
    )
    write(
        "source.json",
        {
            "schema": "tnfr.maintained-parent-sha-source.v1",
            "before": record_graph_state(admitted.graph),
            "prediction": prediction,
            "retained_source_receipts": admitted.receipts,
        },
    )
    files = {
        p.relative_to(ROOT).as_posix(): p.read_bytes()
        for p in sorted((ROOT / "src/tnfr").rglob("*.py"))
    }
    files["pyproject.toml"] = (ROOT / "pyproject.toml").read_bytes()
    files["instrument.py"] = Path(__file__).read_bytes()
    write(
        "source-manifest.json",
        {
            "schema": "tnfr.source-manifest.v1",
            "files": tuple(
                {"path": name, "bytes": len(data), "sha256": sha256_bytes(data)}
                for name, data in sorted(files.items())
            ),
        },
    )
    with ZipFile(OUT / "source.zip", "x", compression=ZIP_DEFLATED) as archive:
        for name, data in sorted(files.items()):
            archive.writestr(name, data)
    prior = tuple(
        receipt(path)
        for path in sorted((ROOT / "docs/assets").rglob("*"))
        if path.is_file() and not path.is_relative_to(OUT)
    )
    write(
        "freeze.json",
        {
            "schema": "tnfr.maintained-parent-sha-freeze.v1",
            "evaluation_status_at_freeze": "not_evaluated",
            "git_base": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT)
            .decode()
            .strip(),
            "source_policy": "complete current Python source including uncommitted work",
            "artifacts": tuple(
                receipt(OUT / name, name)
                for name in (
                    "protocol.json",
                    "source.json",
                    "source-manifest.json",
                    "source.zip",
                )
            ),
            "prior_artifacts": prior,
        },
    )
    print(
        f"Frozen {len(files)} source members and {len(prior)} prior artifact receipts; SHA not executed",
        flush=True,
    )


def check_frozen():
    frozen = read(OUT / "freeze.json")
    verify(OUT, frozen["artifacts"])
    verify(ROOT, frozen["prior_artifacts"])
    rows = read(OUT / "source-manifest.json")["files"]
    verify_archive_members(
        OUT / "source.zip", {row["path"]: row["sha256"] for row in rows}
    )
    for row in rows:
        path = Path(__file__) if row["path"] == "instrument.py" else ROOT / row["path"]
        if receipt(path, row["path"]) != row:
            raise ValueError(f"live producer differs from freeze: {row['path']}")


def evaluate():
    from tnfr.research.maintained_parent_sha_execution import (
        check_sha_endpoint,
        evaluate_sha_event,
    )

    if any(
        (OUT / name).exists()
        for name in (
            "attempt.json",
            "raw-after.json",
            "response.json",
            "report.json",
            "failure.json",
        )
    ):
        raise FileExistsError("reserved SHA attempt already exists")
    check_frozen()
    admitted, frozen_source = source(), read(OUT / "source.json")
    prediction = predict_parent_sha(admitted)
    frozen_graph = restore_recorded_graph_state(frozen_source["before"]).graph
    if (
        _signature(admitted.graph) != _signature(frozen_graph)
        or not same(prediction, frozen_source["prediction"])
        or not same(admitted.receipts, frozen_source["retained_source_receipts"])
    ):
        raise ValueError("SHA source or prospective prediction differs")
    write(
        "attempt.json",
        {
            "schema": "tnfr.maintained-parent-sha-attempt.v1",
            "freeze": receipt(OUT / "freeze.json", "freeze.json"),
            "attempt_number": 1,
            "evaluation_status_at_start": "not_evaluated",
            "created_utc": datetime.now(timezone.utc).isoformat(),
            "python": sys.version,
            "platform": platform.platform(),
            "versions": {
                name: version(name) for name in ("numpy", "networkx", "mpmath")
            },
            "seed": 17,
            "backend": "binary64 canonical SHA; rational/dyadic interval admission",
        },
    )
    try:
        response = evaluate_sha_event(
            admitted,
            frozen_before=frozen_source["before"],
            prediction=prediction,
            on_raw=lambda raw: write("raw-after.json", raw),
        )
        write("response.json", response)
        before = source()
        _raw, endpoint = (
            restore_recorded_graph_state(response[key]).graph
            for key in ("raw_after", "endpoint")
        )
        assessment = check_sha_endpoint(
            before, _raw, endpoint, prediction=prediction, stage=response["stage"]
        )
        check_frozen()
        write(
            "report.json",
            {
                "schema": "tnfr.maintained-parent-sha-report.v1",
                "attempt": receipt(OUT / "attempt.json", "attempt.json"),
                "response": receipt(OUT / "response.json", "response.json"),
                "raw_after": receipt(OUT / "raw-after.json", "raw-after.json"),
                "assessment": assessment,
            },
        )
        print(
            f"SHA checks:{sum(assessment['checks'].values())}/{len(assessment['checks'])}",
            flush=True,
        )
        print(
            f"Failed checks:{[k for k, v in assessment['checks'].items() if not v]}",
            flush=True,
        )
        return 0 if assessment["all_checks_passed"] else 1
    except BaseException:
        write(
            "failure.json",
            {
                "schema": "tnfr.maintained-parent-sha-failure.v1",
                "attempt": receipt(OUT / "attempt.json", "attempt.json"),
                "diagnostic": traceback.format_exc(),
            },
        )
        write("failure-endpoint.json", record_graph_state(admitted.graph))
        raise


if __name__ == "__main__":
    result = {"freeze": freeze, "evaluate": evaluate}[sys.argv[1]]()
    raise SystemExit(result or 0)

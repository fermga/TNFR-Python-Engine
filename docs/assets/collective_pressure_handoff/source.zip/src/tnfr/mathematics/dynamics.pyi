from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, NamedTuple, Sequence

import numpy as np

from .backend import MathematicsBackend
from .spaces import HilbertSpace

__all__ = ["MathematicalDynamicsEngine", "ContractiveDynamicsEngine"]

class TraceValue(NamedTuple):
    backend: Any
    numpy: complex | None

@dataclass
class MathematicalDynamicsEngine:
    hilbert_space: HilbertSpace
    atol: float = ...
    backend: MathematicsBackend = field(init=False, repr=False)
    def __init__(
        self,
        generator: Sequence[Sequence[complex]] | np.ndarray | Any,
        hilbert_space: HilbertSpace,
        *,
        atol: float = 1e-09,
        use_scipy: bool | None = None,
        backend: MathematicsBackend | None = None,
    ) -> None: ...
    @property
    def generator(self) -> np.ndarray: ...
    def step(
        self,
        state: Sequence[complex] | np.ndarray | Any,
        *,
        dt: float = 1.0,
        normalize: bool = True,
    ) -> Any: ...
    def evolve(
        self,
        state: Sequence[complex] | np.ndarray | Any,
        *,
        steps: int,
        dt: float = 1.0,
        normalize: bool = True,
    ) -> Any: ...

@dataclass
class ContractiveDynamicsEngine:
    hilbert_space: HilbertSpace
    atol: float = ...
    backend: MathematicsBackend = field(init=False, repr=False)
    def __init__(
        self,
        generator: Sequence[Sequence[complex]] | np.ndarray | Any,
        hilbert_space: HilbertSpace,
        *,
        atol: float = 1e-09,
        ensure_contractive: bool = True,
        use_scipy: bool | None = None,
        backend: MathematicsBackend | None = None,
    ) -> None: ...
    @property
    def generator(self) -> np.ndarray: ...
    def frobenius_norm(
        self,
        density: Sequence[Sequence[complex]] | np.ndarray | Any,
        *,
        center: bool = False,
    ) -> float: ...
    @property
    def last_contractivity_gap(self) -> float: ...
    def step(
        self,
        density: Sequence[Sequence[complex]] | np.ndarray | Any,
        *,
        dt: float = 1.0,
        normalize_trace: bool = True,
        enforce_contractivity: bool = True,
        raise_on_violation: bool = False,
        symmetrize: bool = True,
    ) -> Any: ...
    def evolve(
        self,
        density: Sequence[Sequence[complex]] | np.ndarray | Any,
        *,
        steps: int,
        dt: float = 1.0,
        normalize_trace: bool = True,
        enforce_contractivity: bool = True,
        raise_on_violation: bool = False,
        symmetrize: bool = True,
    ) -> Any: ...

"""Immutable one-attempt instrument; invoke freeze before evaluate."""
import os
import platform
import subprocess
import sys
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(r"C:\TNFR-Python-Engine")
sys.path.insert(0, str(ROOT / "src"))
from tnfr.research.artifact_io import (
    decode_exact_tree, encode_exact_tree, file_receipt, sha256_bytes,
    verify_archive_members, write_json_once,
)
from tnfr.research.local_capacity_history import encode_result, TIMES
from tnfr.research.maintained_parent_um_source import load_thol_successor
from tnfr.research.maintained_successor_motion_certificate import (
    HORIZON, STEP, STEP_COUNT, ORDER, WALL_BUDGET_SECONDS,
    prepare_motion, certify_motion,
)
from tnfr.utils.io import json_dumps, json_loads

OUT = ROOT / "docs/assets/successor_nonstationary"


def load(name):
    return decode_exact_tree(json_loads((OUT / name).read_bytes()))


def source():
    return load_thol_successor(
        ROOT / "docs/assets/maintained_parent_thol", repository_root=ROOT
    ).graph


def write(name, value):
    write_json_once(OUT / name, encode_result(value))


def receipt(path, label=None):
    return file_receipt(path, label=label or path.relative_to(ROOT).as_posix())


def freeze():
    OUT.mkdir(parents=True, exist_ok=False)
    prediction, initial, _ = prepare_motion(source())
    protocol = {
        "schema": "tnfr.successor-nonstationary-protocol.v1",
        "evaluation_status_at_freeze": "not_evaluated",
        "source": "unchanged hypothetical default UM after retained THOL",
        "preparation": "conditional independent changed-output allowance 2^-40; ideal source included",
        "node_order": prediction.chamber.reset.nodes,
        "law": "x_dot=M*S(theta); theta_dot=M*L_W*x; M=diag(nu/(pi*d))",
        "support": "all 53 held edges; 42 full coordinates; weights/capacities held",
        "pressure": "refreshed bare-neighbor sine row/(pi*d), no Gamma or loss",
        "clock": "elapsed structural time t from hypothetical reset; no laboratory conversion",
        "prior_clock": TIMES[-1], "horizon": HORIZON, "step": STEP,
        "maximum_steps": STEP_COUNT, "order": ORDER,
        "wall_budget_seconds_between_steps": WALL_BUDGET_SECONDS,
        "maximum_attempts": 1, "seed": None,
        "method": "shared direct-source-box Picard/Taylor, outward dyadic128",
        "readouts": [
            "strict all-53 original branch margin over each whole-time tube, or independent fixed-window storage bound",
            "child20-parent2 relative phase velocity at all 256 predetermined endpoints; at least one strictly positive after initially negative",
        ],
        "joint_target": "retain all branches through 1/2 and certify at least one velocity reversal",
        "stop": "first unresolved enclosure/branch margin/resource stop; retain all prior records; no retries or retuning",
        "scope": "conditional mathematical continuation; no actual UM/SHA/runtime trajectory; no physical identification",
        "preflight": "41 slow edges retained by energy; 42 <= box cap64; order12 <=16; fast restoring coefficient about1475.69; wrapping success unknown",
    }
    write("protocol.json", protocol)
    write("source.json", {"prediction": prediction, "initial_box": initial})
    files = {path.relative_to(ROOT).as_posix(): path.read_bytes()
             for path in sorted((ROOT / "src/tnfr").rglob("*.py"))}
    files["pyproject.toml"] = (ROOT / "pyproject.toml").read_bytes()
    files["instrument.py"] = Path(__file__).read_bytes()
    manifest = {"schema": "tnfr.source-manifest.v1", "files": [
        {"path": name, "bytes": len(raw), "sha256": sha256_bytes(raw)}
        for name, raw in sorted(files.items())
    ]}
    write("source-manifest.json", manifest)
    with ZipFile(OUT / "source.zip", "x", compression=ZIP_DEFLATED) as archive:
        for name, raw in sorted(files.items()):
            archive.writestr(name, raw)
    prior = [receipt(path) for path in sorted((ROOT / "docs/assets").rglob("*"))
             if path.is_file() and not path.is_relative_to(OUT)]
    write("freeze.json", {
        "schema": "tnfr.successor-nonstationary-freeze.v1",
        "evaluation_status_at_freeze": "not_evaluated",
        "git_base": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT).decode().strip(),
        "source_policy": "complete current Python source archive, including uncommitted work",
        "artifacts": [receipt(OUT / name, name) for name in
                      ("protocol.json", "source.json", "source-manifest.json", "source.zip")],
        "prior_artifacts": prior,
    })
    print(f"FROZEN: {len(files)} source files, {len(prior)} prior assets; response not evaluated", flush=True)


def check_frozen():
    frozen = load("freeze.json")
    for item in frozen["artifacts"]:
        if receipt(OUT / item["path"], item["path"]) != item:
            raise ValueError("frozen artifact bytes differ")
    for item in frozen["prior_artifacts"]:
        if receipt(ROOT / item["path"]) != item:
            raise ValueError("prior artifact bytes differ")
    manifest = load("source-manifest.json")
    expected = {item["path"]: item["sha256"] for item in manifest["files"]}
    verify_archive_members(OUT / "source.zip", expected)
    for item in manifest["files"]:
        path = Path(__file__) if item["path"] == "instrument.py" else ROOT / item["path"]
        if receipt(path, item["path"]) != item:
            raise ValueError("live source bytes differ from frozen source")
    return frozen


def evaluate():
    check_frozen()
    write("attempt.json", {
        "schema": "tnfr.successor-nonstationary-attempt.v1",
        "freeze": receipt(OUT / "freeze.json", "freeze.json"),
        "evaluation_status_at_start": "not_evaluated", "attempt_number": 1,
        "python": sys.version, "platform": platform.platform(),
        "seed": None, "backend": "Python exact Fraction / rational dyadic128 intervals",
    })
    entries = []
    (OUT / "steps").mkdir(exist_ok=False)

    def record(value):
        name = f"step-{value['index']:03d}.json"
        raw = (json_dumps(encode_exact_tree(encode_result(value)), sort_keys=True,
                          separators=(",", ":"), allow_nan=False) + "\n").encode()
        # Independent exclusive archives never rewrite preceding step bytes.
        relative = f"steps/{value['index']:03d}.zip"
        path = OUT / relative
        with ZipFile(path, "x", compression=ZIP_DEFLATED) as archive:
            archive.writestr(name, raw)
        with path.open("r+b") as stream:
            os.fsync(stream.fileno())
        entries.append({"artifact": receipt(path, relative),
                        "member": {"path": name, "bytes": len(raw), "sha256": sha256_bytes(raw)}})
        if value["index"] % 8 == 0 or value["step"] is None:
            margin = value.get("combined_principal_margins")
            velocity = value.get("endpoint_relative_velocity")
            print(f"step {value['index']+1}: margin={None if margin is None else float(min(margin))}; "
                  f"velocity={None if velocity is None else (float(velocity.lo), float(velocity.hi))}; "
                  f"reason={value.get('reason')}", flush=True)

    try:
        result = certify_motion(source(), record_step=record)
        check_frozen()
        write("result.json", {
            "schema": "tnfr.successor-nonstationary-result.v1",
            "attempt": receipt(OUT / "attempt.json", "attempt.json"),
            "records": entries, "report": result,
        })
        print(json_dumps(encode_exact_tree(encode_result(result))), flush=True)
    except BaseException as exc:
        write("incomplete.json", {
            "exception": type(exc).__name__, "message": str(exc), "records": entries,
            "attempt": receipt(OUT / "attempt.json", "attempt.json"),
        })
        raise


if __name__ == "__main__":
    {"freeze": freeze, "evaluate": evaluate}[sys.argv[1]]()

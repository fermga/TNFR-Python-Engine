"""First fixed spatial projection; earlier full-coordinate evidence is prior data."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'src'))

from datetime import datetime, timezone
import platform
import time
import traceback
import zipfile

from tnfr.research.artifact_io import (
    decode_exact_tree, file_receipt, read_bytes_bounded, sha256_bytes, write_json_once,
)
from tnfr.utils.io import json_loads

HERE = Path(__file__).resolve().parent
policy_path = HERE / 'policy-v1.json'
policy = decode_exact_tree(json_loads(read_bytes_bounded(policy_path, max_bytes=2**16)))
source_paths = (
    'src/tnfr/physics/relational_sine_class_spatial_observation.py',
    'src/tnfr/physics/relational_sine_class_cubic_response.py',
    'src/tnfr/physics/_sine_class_contrast.py',
    'src/tnfr/physics/relational_sine_class_superposition.py',
    'src/tnfr/physics/relational_sine_class_mediation.py',
    'src/tnfr/physics/relational_sine_port_composition.py',
    'src/tnfr/physics/_sine_port_geometry.py',
    'src/tnfr/physics/_sine_port_bounds.py',
    'src/tnfr/mathematics/_rational_interval.py',
    'src/tnfr/mathematics/_comparison_flow.py',
    'src/tnfr/_exact_time.py',
    'src/tnfr/sdk/relational_reports.py',
    'src/tnfr/research/artifact_io.py',
    'src/tnfr/utils/io.py',
    'theory/nodal/SINE_CLASS_SPATIAL_OBSERVATION.md',
)
sources = {name: file_receipt(ROOT / name, max_bytes=2**20) for name in source_paths}
reference = policy['coefficient_reference']
prior_path = ROOT / reference['path']
prior_receipt = file_receipt(prior_path, max_bytes=2**27)
assert prior_receipt['sha256'] == reference['sha256']
archive = HERE / 'evaluated-source-v1.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for name in source_paths:
        z.write(ROOT / name, name)
    z.write(policy_path, policy_path.name)
    z.write(__file__, Path(__file__).name)
attempt = {
    'schema': 'tnfr.sine-class-spatial-observation-attempt.v1',
    'started_utc': datetime.now(timezone.utc).isoformat(),
    'policy': file_receipt(policy_path),
    'evaluated_source_archive': file_receipt(archive),
    'evaluated_sources': sources,
    'coefficient_reference': prior_receipt,
    'python': sys.version, 'platform': platform.platform(),
    'scope': policy['scope'], 'retry_policy': policy['first_attempt_policy'],
}
write_json_once(HERE / 'attempt-v1.json', attempt)
start = time.perf_counter()
output = None
matches = None
error = None
try:
    from tnfr.physics.relational_sine_class_spatial_observation import (
        bound_sine_class_spatial_observation,
    )
    report = bound_sine_class_spatial_observation(**policy['inputs'])
    output = report.to_dict()
    with zipfile.ZipFile(prior_path) as z:
        assert len(z.namelist()) == len(set(z.namelist()))
        info = z.getinfo(reference['outcome_member'])
        assert info.file_size == 33439119
        with z.open(info) as stream:
            raw = stream.read(33439120)
    assert len(raw) == 33439119
    assert sha256_bytes(raw) == reference['outcome_sha256']
    prior = json_loads(raw)['output']['report']
    matches = {name: output['report'][name] == prior[name]
               for name in reference['reused_report_fields']}
    if not all(matches.values()):
        raise RuntimeError('Reused full-coordinate evidence changed; preserve full output.')
    for name in reference['reused_report_fields']:
        del output['report'][name]
    output['schema'] = 'tnfr.sine-class-spatial-observation-compact.v1'
    output['coefficient_evidence_reference'] = reference
except Exception:
    error = traceback.format_exc()
result = {
    'schema': 'tnfr.sine-class-spatial-observation-outcome.v1',
    'attempt': file_receipt(HERE / 'attempt-v1.json'),
    'elapsed_seconds': time.perf_counter() - start,
    'reused_field_equality': matches,
    'output': output, 'error': error,
}
write_json_once(HERE / 'outcome-v1.json', result)
print('elapsed_seconds', result['elapsed_seconds'], flush=True)
if error:
    print(error, flush=True)
else:
    print('status', report.status, flush=True)
    print('quadratic', tuple(float(x) for x in report.complete_quadratic_contrast_bounds), flush=True)
    print('higher', float(report.higher_amplitude_contrast_error_upper_bound), flush=True)
    print('source', float(report.source_contrast_error_upper_bound), flush=True)
    print('true', tuple(float(x) for x in report.decision.true_bounds), flush=True)
    print('recorded', tuple(float(x) for x in report.decision.recorded_bounds), flush=True)
    print('null_margin', float(report.decision.null_separation_margin), flush=True)
    print('scalar_cancellation', report.decision.scalar_cancellation, flush=True)
    print('reused_field_equality', matches, flush=True)

"""Evaluate the already frozen formed-class contact protocol once."""

from fractions import Fraction as Q
from pathlib import Path
import sys

sys.path.insert(0, str(Path.cwd() / "src"))

from tnfr.physics.relational_sine_formed_class_contact import (
    assess_sine_formed_class_contact,
)
from tnfr.sdk import export_to_json
from tnfr.utils.io import json_loads

root = Path("docs/assets/sine_formed_classes")
output = root / "contact-v1.json"
if output.exists():
    raise RuntimeError("The reserved result already exists; do not overwrite it")
if not (root / "contact-v1.source.zip").is_file():
    raise RuntimeError("Archive the protocol and source before evaluation")
protocol = json_loads((root / "contact-v1.protocol.json").read_text(encoding="utf-8"))
inputs = {
    key: Q(value["numerator"], value["denominator"])
    if isinstance(value, dict)
    else value
    for key, value in protocol["inputs"].items()
}
report = assess_sine_formed_class_contact(**inputs)
export_to_json(report.to_dict(), output)
threshold = protocol["prediction"]["recorded_class_two_minus_one_lower_threshold"]
threshold = Q(threshold["numerator"], threshold["denominator"])
passed = (
    report.status == "certified_formed_class_contact"
    and report.recorded_contrast_bounds.lo > threshold
)
print("Status:", report.status)
print("Frozen stopping rule:", passed)
for name in (
    "recorded_contrast_bounds",
    "ideal_leading_contrast_bounds",
    "semigroup_tail_upper_bound",
    "nonlinear_remainder_upper_bound",
    "preparation_response_error_upper_bound",
    "joined_radius_margin_bounds",
    "joined_storage_margin_bounds",
    "bridge_work_bounds",
    "work_margin_bounds",
    "decay_exponent",
):
    print(name, getattr(report, name))

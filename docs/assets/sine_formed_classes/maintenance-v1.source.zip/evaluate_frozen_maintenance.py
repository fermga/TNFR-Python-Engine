"""Evaluate the frozen analytic return certificate once from exact primitives."""
from fractions import Fraction
from pathlib import Path
import sys

root = Path.cwd()
sys.path.insert(0, str(root / "src"))
from tnfr.utils.io import json_loads
from tnfr.sdk import export_to_json
from tnfr.physics.relational_sine_formed_class_maintenance import (
    assess_sine_formed_class_maintenance,
)

folder = root / "docs/assets/sine_formed_classes"
protocol = json_loads((folder / "maintenance-v1.protocol.json").read_text(encoding="utf-8"))
output = folder / "maintenance-v1.json"
if output.exists():
    raise FileExistsError("Retained response already exists; use a separately declared protocol")
inputs = {
    name: Fraction(value["numerator"], value["denominator"])
    for name, value in protocol["inputs"].items()
}
report = assess_sine_formed_class_maintenance(**inputs)
export_to_json(report, output)
print("status:", report.status)
print("reasons:", report.unavailable_reasons)
print("return_flags:", report.return_certified_by_class)
print("decay_rate:", float(report.lyapunov_decay_rate) if report.lyapunov_decay_rate else None)
print("decay_upper:", float(report.exponential_decay_bounds.hi) if report.exponential_decay_bounds else None)
print("response_lower:", float(report.reference_certificate.recorded_contrast_bounds.lo))
if report.form_return_margin_bounds is not None:
    print("form_squared_return_margins:", tuple(float(item.lo) for item in report.form_return_margin_bounds))
    print("phase_squared_return_margins:", tuple(float(item.lo) for item in report.phase_return_margin_bounds))
print("saved:", output)

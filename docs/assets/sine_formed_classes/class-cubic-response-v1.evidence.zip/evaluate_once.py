from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'src'))
from datetime import datetime, timezone
import platform
import time
import traceback
import zipfile
from tnfr.research.artifact_io import decode_exact_tree, file_receipt, write_json_once
from tnfr.utils.io import json_loads

HERE = Path(__file__).resolve().parent
policy_path = HERE / 'policy-v1.json'
policy = decode_exact_tree(json_loads(policy_path.read_text(encoding='utf-8')))
source_paths = (
    'src/tnfr/physics/relational_sine_class_cubic_response.py',
    'src/tnfr/physics/_sine_class_contrast.py',
    'src/tnfr/physics/relational_sine_class_superposition.py',
    'src/tnfr/physics/relational_sine_class_mediation.py',
    'src/tnfr/physics/relational_sine_port_composition.py',
    'src/tnfr/physics/_sine_port_geometry.py',
    'src/tnfr/physics/_sine_port_bounds.py',
    'src/tnfr/mathematics/_rational_interval.py',
    'src/tnfr/mathematics/_comparison_flow.py',
    'src/tnfr/_exact_time.py',
)
archive = HERE / 'evaluated-source-v1-complete.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for name in source_paths:
        z.write(ROOT / name, name)
    z.write(policy_path, policy_path.name)
    z.write(__file__, Path(__file__).name)
attempt = {
    'schema': 'tnfr.sine-class-cubic-response-attempt.v1',
    'started_utc': datetime.now(timezone.utc).isoformat(),
    'policy': file_receipt(policy_path),
    'evaluated_source_archive': file_receipt(archive),
    'evaluated_runtime': {name: file_receipt(ROOT / name) for name in source_paths},
    'python': sys.version,
    'platform': platform.platform(),
    'scope': 'First fixed analytic amplitude-coefficient calculation; no nonlinear trajectory or source acquisition.',
    'retry_policy': 'No retry or numerical policy change after this ledger.',
}
write_json_once(HERE / 'attempt-v1.json', attempt)
start = time.perf_counter()
try:
    from tnfr.physics.relational_sine_class_cubic_response import bound_sine_class_cubic_response
    report = bound_sine_class_cubic_response(**policy['inputs'])
    result = {'schema': 'tnfr.sine-class-cubic-response-outcome.v1',
              'attempt': file_receipt(HERE / 'attempt-v1.json'),
              'elapsed_seconds': time.perf_counter() - start,
              'output': report.to_dict(), 'error': None}
except Exception:
    result = {'schema': 'tnfr.sine-class-cubic-response-outcome.v1',
              'attempt': file_receipt(HERE / 'attempt-v1.json'),
              'elapsed_seconds': time.perf_counter() - start,
              'output': None, 'error': traceback.format_exc()}
write_json_once(HERE / 'outcome-v1.json', result)
print('elapsed_seconds', result['elapsed_seconds'], flush=True)
if result['error']:
    print(result['error'], flush=True)
else:
    print('status', report.status, flush=True)
    print('cubic', tuple(float(x) for x in report.complete_cubic_contrast_bounds), flush=True)
    print('higher', float(report.higher_amplitude_contrast_error_upper_bound), flush=True)
    print('source', float(report.source_contrast_error_upper_bound), flush=True)
    print('true', tuple(float(x) for x in report.decision.true_bounds), flush=True)
    print('recorded', tuple(float(x) for x in report.decision.recorded_bounds), flush=True)
    print('scalar_cancellation', report.decision.scalar_cancellation, flush=True)

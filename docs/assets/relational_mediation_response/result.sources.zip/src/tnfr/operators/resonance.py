"""Resonance (RA) operator.

Purpose: propagate coherence through coupled phase-aligned nodes.
Physics: circulates structural pattern preserving epi identity (sign/kind).
Grammar: always requires phase-compatible coupling (U3).
Effects: mixes epi preserving sign/kind; configured phase/capacity updates.
No support or stored-pressure write is implied by the propagation label.
Preconditions: coherent epi, edges, phase alignment, sufficient vf.
Typical: UM->RA; IL->RA; AL->RA; RA->IL; RA->EN.
Avoid: OZ->RA without IL; SHA->RA; repeated RA chains without IL.
"""

from __future__ import annotations

from typing import Any, ClassVar

from ..config.operator_names import RESONANCE
from ..types import Glyph, TNFRGraph
from .definitions_base import Operator


class Resonance(Operator):
    """Mix form across compatible neighbors with phase/capacity updates.

    Preserves epi sign/kind; capacity amplification has a separate trigger.
    Global alignment increase and stored-pressure contraction are not promised.
    Typical: UM->RA, IL->RA, AL->RA, RA->IL, RA->EN. Avoid OZ->RA w/o IL.
    Metrics: propagation distance, amplification factor, phase order param.
    """

    __slots__ = ()
    name: ClassVar[str] = RESONANCE
    glyph: ClassVar[Glyph] = Glyph.RA

    def _validate_hard_invariants(self, G: TNFRGraph, node: Any) -> None:
        """U3 phase gate (Invariant #2) — always enforced, cannot be disabled."""
        from .preconditions import validate_phase_gate_u3

        validate_phase_gate_u3(G, node, "Resonance")

    def _validate_preconditions(self, G: TNFRGraph, node: Any) -> None:
        """Validate RA-specific preconditions."""
        from .preconditions import validate_resonance

        validate_resonance(G, node)

    def _collect_metrics(
        self, G: TNFRGraph, node: Any, state_before: dict[str, Any]
    ) -> dict[str, Any]:
        """Collect RA metrics including vf amplification tracking."""
        from .metrics import resonance_metrics

        return resonance_metrics(
            G,
            node,
            state_before["epi"],
            vf_before=state_before["vf"],  # vf for amplification tracking
        )

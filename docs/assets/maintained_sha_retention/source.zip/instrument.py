"""One prospective actual post-SHA retention attempt; freeze before evaluate."""

import os
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(r"C:\TNFR-Python-Engine")
sys.path.insert(0, str(ROOT / "src"))
from tnfr.research.artifact_io import (
    decode_exact_tree,
    encode_exact_tree,
    file_receipt,
    sha256_bytes,
    validate_artifact_path,
    verify_archive_members,
    write_json_once,
)
from tnfr.research.local_capacity_history import encode_result, TIMES
from tnfr.research.maintained_sha_motion_source import load_sha_successor
from tnfr.research.maintained_sha_motion import (
    prepare_sha_motion,
    certify_sha_retention,
)
from tnfr.research.maintained_principal_retention import (
    HORIZON,
    STEP,
    STEP_COUNT,
    ORDER,
    WALL_BUDGET_SECONDS,
)
from tnfr.research.maintained_parent_thol import _signature
from tnfr.research.retained_graph_state import (
    record_graph_state,
    restore_recorded_graph_state,
)
from tnfr.utils.io import json_dumps, json_loads

OUT = ROOT / "docs/assets/maintained_sha_retention"


def load(name):
    return decode_exact_tree(json_loads((OUT / name).read_bytes()))


def source():
    return load_sha_successor(
        ROOT / "docs/assets/maintained_parent_sha", repository_root=ROOT
    )


def same(left, right):
    return json_dumps(
        encode_exact_tree(encode_result(left)), sort_keys=True
    ) == json_dumps(encode_exact_tree(encode_result(right)), sort_keys=True)


def write(name, value):
    write_json_once(OUT / name, encode_result(value))


def receipt(path, label=None):
    return file_receipt(path, label=label or path.relative_to(ROOT).as_posix())


def freeze():
    admitted = source()
    prediction, initial, _ = prepare_sha_motion(admitted)
    OUT.mkdir(parents=True, exist_ok=False)
    write(
        "protocol.json",
        {
            "schema": "tnfr.maintained-sha-retention-protocol.v1",
            "evaluation_status_at_freeze": "not_evaluated",
            "source": "actual committed VAL,THOL,UM,SHA endpoint, independently re-admitted",
            "preparation": "exact represented source point; all x, real phase lifts, capacities and conductances; no inherited UM output-family allowance",
            "node_order": prediction.nodes,
            "law": "x_dot=M*S(theta); theta_dot=M*L_W*x; M=diag(nu/(pi*d))",
            "support": "all 53 held edges; all 42 coordinates; actual post-SHA positive capacities and conductances held",
            "pressure": "bare-neighbor sine row/(pi*d) evaluated throughout the complete field; no Gamma or loss",
            "clock": "elapsed original structural time from actual SHA endpoint; no laboratory conversion",
            "prior_clock": TIMES[-1],
            "horizon": HORIZON,
            "step": STEP,
            "maximum_steps": STEP_COUNT,
            "order": ORDER,
            "wall_budget_seconds_between_steps": WALL_BUDGET_SECONDS,
            "resource_clock_scope": "starts before fresh preparation in certify_sha_retention; checked between steps; excludes prior freeze/source equality checks",
            "maximum_attempts": 1,
            "maximum_events": 0,
            "seed": None,
            "method": "shared direct-source-box Picard/Taylor, outward dyadic128",
            "readouts": (
                "strict all-53 original branch margin over each whole-time tube, or independent rebuilt fixed-window storage bound",
            ),
            "target": "all 53 original principal branches retained throughout elapsed [0,1/2]",
            "stop": "first unresolved enclosure/branch margin/resource stop; preserve prior records; no retries, retuning or IL",
            "scope": "finite conditional complete-law continuation of an actual operator endpoint; no runtime event, turning-time target, periodicity, all-time confinement, formation or physical identification",
            "preflight": "fresh analytical storage bounds certify41/53; exactly12 parent-incident edges remain unresolved; full42-state certificate required",
            "evidence_limit": "recorded derivative jets and remainders retain frozen producer provenance; read-only audits reconstruct inclusion and arithmetic without regenerating jets",
        },
    )
    write(
        "source.json",
        {
            "schema": "tnfr.maintained-sha-retention-source.v1",
            "endpoint": record_graph_state(admitted.graph),
            "retained_source_receipts": admitted.receipts,
            "prediction": prediction,
            "initial_box": initial,
        },
    )
    files = {
        path.relative_to(ROOT).as_posix(): path.read_bytes()
        for path in sorted((ROOT / "src/tnfr").rglob("*.py"))
    }
    files["pyproject.toml"] = (ROOT / "pyproject.toml").read_bytes()
    files["instrument.py"] = Path(__file__).read_bytes()
    write(
        "source-manifest.json",
        {
            "schema": "tnfr.source-manifest.v1",
            "files": [
                {"path": name, "bytes": len(raw), "sha256": sha256_bytes(raw)}
                for name, raw in sorted(files.items())
            ],
        },
    )
    with ZipFile(OUT / "source.zip", "x", compression=ZIP_DEFLATED) as archive:
        for name, raw in sorted(files.items()):
            archive.writestr(name, raw)
    prior = [
        receipt(path)
        for path in sorted((ROOT / "docs/assets").rglob("*"))
        if path.is_file() and not path.is_relative_to(OUT)
    ]
    write(
        "freeze.json",
        {
            "schema": "tnfr.maintained-sha-retention-freeze.v1",
            "evaluation_status_at_freeze": "not_evaluated",
            "git_base": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT)
            .decode()
            .strip(),
            "source_policy": "complete current Python source archive, including uncommitted work",
            "artifacts": [
                receipt(OUT / name, name)
                for name in (
                    "protocol.json",
                    "source.json",
                    "source-manifest.json",
                    "source.zip",
                )
            ],
            "prior_artifacts": prior,
        },
    )
    print(
        f"FROZEN: {len(files)} source files, {len(prior)} prior assets; response not evaluated",
        flush=True,
    )


def check_frozen():
    frozen = load("freeze.json")
    for base, rows in ((OUT, frozen["artifacts"]), (ROOT, frozen["prior_artifacts"])):
        for item in rows:
            name = validate_artifact_path(item["path"])
            path = (base / name).resolve()
            if not path.is_relative_to(base.resolve()) or receipt(path, name) != item:
                raise ValueError("frozen/prior artifact bytes differ")
    manifest = load("source-manifest.json")
    expected = {item["path"]: item["sha256"] for item in manifest["files"]}
    verify_archive_members(OUT / "source.zip", expected)
    for item in manifest["files"]:
        path = (
            Path(__file__) if item["path"] == "instrument.py" else ROOT / item["path"]
        )
        if receipt(path, item["path"]) != item:
            raise ValueError("live source bytes differ from frozen source")


def evaluate():
    if any(
        (OUT / name).exists()
        for name in ("attempt.json", "result.json", "incomplete.json", "steps")
    ):
        raise FileExistsError("reserved retention attempt already exists")
    check_frozen()
    admitted = source()
    prediction, initial, _ = prepare_sha_motion(admitted)
    retained = load("source.json")
    if (
        _signature(admitted.graph)
        != _signature(restore_recorded_graph_state(retained["endpoint"]).graph)
        or not same(prediction, retained["prediction"])
        or not same(initial, retained["initial_box"])
        or not same(admitted.receipts, retained["retained_source_receipts"])
    ):
        raise ValueError("prospective actual SHA source differs")
    write(
        "attempt.json",
        {
            "schema": "tnfr.maintained-sha-retention-attempt.v1",
            "freeze": receipt(OUT / "freeze.json", "freeze.json"),
            "evaluation_status_at_start": "not_evaluated",
            "attempt_number": 1,
            "created_utc": datetime.now(timezone.utc).isoformat(),
            "python": sys.version,
            "platform": platform.platform(),
            "seed": None,
            "backend": "Python exact Fraction / rational dyadic128 intervals",
        },
    )
    entries = []
    (OUT / "steps").mkdir(exist_ok=False)

    def record(value):
        name = f"step-{value['index']:03d}.json"
        raw = (
            json_dumps(
                encode_exact_tree(encode_result(value)),
                sort_keys=True,
                separators=(",", ":"),
                allow_nan=False,
            )
            + "\n"
        ).encode()
        relative = f"steps/{value['index']:03d}.zip"
        path = OUT / relative
        with ZipFile(path, "x", compression=ZIP_DEFLATED) as archive:
            archive.writestr(name, raw)
        with path.open("r+b") as stream:
            os.fsync(stream.fileno())
        entries.append(
            {
                "artifact": receipt(path, relative),
                "member": {
                    "path": name,
                    "bytes": len(raw),
                    "sha256": sha256_bytes(raw),
                },
            }
        )
        if value["index"] % 8 == 0 or value["step"] is None:
            margins = value.get("combined_principal_margins")
            print(
                f"step {value['index']+1}: margin={None if margins is None else float(min(margins))}; reason={value.get('reason')}",
                flush=True,
            )

    try:
        result = certify_sha_retention(admitted, record_step=record)
        check_frozen()
        write(
            "result.json",
            {
                "schema": "tnfr.maintained-sha-retention-result.v1",
                "attempt": receipt(OUT / "attempt.json", "attempt.json"),
                "records": entries,
                "report": result,
            },
        )
        print(json_dumps(encode_exact_tree(encode_result(result))), flush=True)
    except BaseException as exc:
        write(
            "incomplete.json",
            {
                "exception": type(exc).__name__,
                "message": str(exc),
                "records": entries,
                "attempt": receipt(OUT / "attempt.json", "attempt.json"),
            },
        )
        raise


if __name__ == "__main__":
    {"freeze": freeze, "evaluate": evaluate}[sys.argv[1]]()

#!/usr/bin/env python3
"""
TNFR Canonical Constants
========================

Shared mathematical values and compatibility names for configured TNFR defaults.
Subsystem configuration remains owned by ``tnfr.config``. Nodal equation:

∂EPI/∂t = νf · ΔNFR(t)

The phase definitions give exact bounds |∇φ| ≤ π and |K_φ| ≤ π. The curvature
warning 0.9·π is a selected margin. K_φ approaches L_rw·φ only in the
small-phase-spread regime with matching neighbor weights. The spectral
coherence-length reference is 1/√λ₂ on connected undirected graphs; a fitted
correlation length need not equal that reference.

Potential is linear in pressure: Φ_s = B_G·ΔNFR. Its general norm bound depends
on pressure and the graph kernel B_G. The π/4 per-node and π/2 U6 drift values
are selected safety policies, not consequences of phase wrapping. See
``theory/DIAGNOSTIC_AND_GRAMMAR_SCOPE.md`` for exact hypotheses and witnesses.

These names include mathematical quantities, selected model/diagnostic
parameters, numerical-method coefficients and inactive compatibility exports.
Their role follows the documented consumer, not this module's historical name.
The classification and unit-change duties are centralized in
``theory/NODAL_PARAMETER_FOUNDATIONS.md`` section 1.1.

Operational engine-tuning knobs (cache sizes, FFT / optimization tuning,
performance / memory estimates, engine scoring weights) carry no nodal-physics
meaning and live in the separate module ``tnfr.constants.operational``
(audit 2026) — they must never be cited as first-principles TNFR results.

The obsolete constants φ (golden ratio), γ (Euler–Mascheroni), and e (Napier)
are intentionally ABSENT: they are not structural scales, and nothing here is
derived from them (audit 2026). Expressing a policy as a π-fraction does not
establish its physical necessity; configured gains and safety values remain
policies unless an explicit derivation supplies the required hypotheses.

Author: TNFR Research Team
Date: November 29, 2025 (φ/γ/e purge 2026-06)
"""

import math

# ============================================================================
# MATHEMATICAL CONSTANTS (represented binary64 values)
# ============================================================================

# Exact circular scale in radians: π, shared by the |∇φ| and |K_φ| bounds.
# This angular bound supplies neither a time unit nor a unique dynamical gain.
# The remaining values have mathematical or operational roles documented below.
# Standard-library values preserve the binary64 constants without changing a
# caller's arbitrary-precision context merely by importing configuration.
PI = math.pi  # Pi π ≈ 3.141592653589793
LN_2 = math.log(2)  # Natural log of 2 ≈ 0.693147180559945 (binary information unit)

# Inverse constants
INV_PI = 1.0 / PI  # 1/π ≈ 0.318309886183791

# ============================================================================
# CIRCULAR (π) HELPER
# ============================================================================

# Semi-inverse circular constant (π-only)
HALF_INV_PI = 1.0 / (2.0 * PI)  # 1/(2π) ≈ 0.159 (semi-inverse circular)

# ============================================================================
# TNFR STRUCTURAL CONSTANTS (only the π phase-wrap bounds and the spectral-gap
# reference for ξ_C is conditional and dimensionless — see header)
# ============================================================================

# Heuristic regime-classification / spectral-shift scale (audit 2026: NOT a
# derived critical exponent; the measured phase-transition exponent is
# protocol-dependent). A small π-fraction, labeled tunable.
CRITICAL_EXPONENT = PI / 16  # π/16 ≈ 0.196 (heuristic regime/shift scale, tunable)

# Selected coherence band, centralized as one value and its complement.
# [1/(π+1), π/(π+1)] ≈ [0.2415, 0.7585] is a telemetry/admission policy;
# neither phase wrapping nor the nodal product derives these cuts.
FRAGMENTATION_THRESHOLD = 1.0 / (
    PI + 1.0
)  # 1/(π+1) ≈ 0.2415 (fragmentation-risk level)
HIGH_COHERENCE_THRESHOLD = PI / (PI + 1.0)  # π/(π+1) ≈ 0.7585 (high-coherence gate)

# Configured channel hierarchy, reused by DNFR_WEIGHTS and SI_WEIGHTS.
# The real-arithmetic identity π/(π+1) + π/(π+1)² + 1/(π+1)² = 1
# normalizes these defaults; it selects neither their ordering nor physical
# channel units. Renormalizing coefficients after a change of units generally
# changes the nodal law. See theory/NODAL_PARAMETER_FOUNDATIONS.md.
CHANNEL_WEIGHT_PRIMARY = HIGH_COHERENCE_THRESHOLD  # π/(π+1) ≈ 0.7585 (dominant channel)
CHANNEL_WEIGHT_SECONDARY = (
    HIGH_COHERENCE_THRESHOLD * FRAGMENTATION_THRESHOLD
)  # π/(π+1)² ≈ 0.1832 (dominant-of-remainder)
CHANNEL_WEIGHT_TERTIARY = (
    FRAGMENTATION_THRESHOLD * FRAGMENTATION_THRESHOLD
)  # 1/(π+1)² ≈ 0.0583 (remainder)

# Configured pressure gains, reciprocal in real arithmetic. The scalar product
# equals one; actual IL/OZ operations also read and change other state, so this
# algebra does not make their composition an isometry or inverse operation.
COHERENCE_RETENTION = (
    HIGH_COHERENCE_THRESHOLD  # π/(π+1) ≈ 0.7585 (IL pressure retention)
)
DISSONANCE_AMPLIFICATION = (
    PI + 1.0
) / PI  # (π+1)/π ≈ 1.3183 (OZ pressure amplification)

# Secondary operator couplings — gentle π-fraction gains at three structural
# scales. Each operator contract fixes its channel and sign; these secondary
# magnitudes are selected π-fractions, on the same configured ladder
# as the adaptation rates UP/DOWN (1/(4π), 1/(2π)) and the coupling floor 1/(8π).
COUPLING_GENTLE = 1.0 / (4.0 * PI)  # 1/(4π) ≈ 0.0796 (gentle secondary gain)
COUPLING_MODERATE = 1.0 / (2.0 * PI)  # 1/(2π) ≈ 0.159 (moderate secondary gain)
COUPLING_FINE = 1.0 / (8.0 * PI)  # 1/(8π) ≈ 0.0398 (fine secondary gain)

# Selected mid-high coherence/force trigger. Its expression 2/π is an exact
# mathematical value, not a derived universal synchronization threshold.
MID_COHERENCE_THRESHOLD = 2.0 / PI  # 2/π ≈ 0.6366 (mid-high coherence trigger)

# Operator gain parameters. The scale operators (Silence, Expansion,
# Contraction) act on the ν_f CAPACITY lever; the contracts fix the DIRECTION
# (ν_f↓ for SHA/NUL, ν_f↑ for VAL). The magnitude δ = 1/(4π) is a configured
# per-invocation step, shared with UP_CANONICAL; no time-scale separation follows
# from the nodal equation alone.
_CAPACITY_STEP = 1.0 / (4.0 * PI)  # 1/(4π) ≈ 0.0796 (gentle ν_f adaptation step)
SHA_VF_FACTOR = 1.0 - _CAPACITY_STEP  # 1 − 1/(4π) ≈ 0.9204 (gentle freeze step)
NUL_SCALE_FACTOR = SHA_VF_FACTOR  # Contraction: same ν_f↓ step as Silence

# VAL expansion thresholds
VAL_MIN_EPI = 1.0 / (2.0 * PI)  # minimum structural base to expand (tunable)
VAL_BIFURCATION_THRESHOLD = (
    FRAGMENTATION_THRESHOLD  # 1/(π+1) ≈ 0.2415 (bifurcation detection)
)
VAL_MIN_COHERENCE = math.sin(
    PI / 3
)  # sin(π/3) = √3/2 ≈ 0.8660 (60° harmonic coherence)

# Deprecated compatibility alias. THOL no longer reads this value and it does
# not certify canonical C(t) or the U5 parent/child target. New code should use
# FRAGMENTATION_THRESHOLD for the coherence-band cut and
# assess_u5_parent_child_coherence(..., alpha=...) for an explicit hierarchy.
THOL_MIN_COLLECTIVE_COHERENCE = FRAGMENTATION_THRESHOLD

# Coupling and mixing thresholds (operational)
# Coupling forms when the composite compatibility (phase 50% + EPI 25% + Si 25%)
# exceeds the HIGH-COHERENCE level π/(π+1), the complement of the fragmentation
# threshold 1/(π+1). The composite score and its cut are configured policies.
UM_COMPAT_THRESHOLD = HIGH_COHERENCE_THRESHOLD  # π/(π+1) ≈ 0.7585 (high-coherence gate)
EN_MIX_FACTOR = FRAGMENTATION_THRESHOLD  # 1/(π+1) ≈ 0.2415 (reception mixing fraction)
UM_THETA_PUSH = EN_MIX_FACTOR  # Shared default, not an EPI/phase physical identity

# Expansion raises the ν_f capacity by the same gentle π-step δ = 1/(4π).
# Contraction configures reciprocal pressure scaling. Capacity is a rate,
# not a geometric volume: identifying the two would require an additional
# constitutive relation. The reciprocal preserves ν_f*ΔNFR only for ideal
# simultaneous scalar rescalings without clipping or other operator effects.
VAL_SCALE_FACTOR = 1.0 + _CAPACITY_STEP  # 1 + 1/(4π) ≈ 1.0796 (gentle expansion step)
NUL_DENSIFICATION_FACTOR = (
    1.0 / NUL_SCALE_FACTOR  # 1/λ ≈ 1.0865 (configured reciprocal densification)
)

# Binary/structural escape threshold = 2.0. This is the EPI dynamic range
# (EPI_MAX − EPI_MIN = 1 − (−1) = 2, the maximum coherent-form span) — a plain
# configured chart span, not a bound on every admissible EPI representation.
STRUCTURAL_ESCAPE_THRESHOLD_THEORETICAL = 2.0  # EPI span (unit form range)


# ============================================================================
# CONFIGURATION CONSTANTS (Magic Number Replacements)
# ============================================================================

# Temporal constants. The integration timestep is a numerical PARAMETER (the
# nodal equation fixes the dynamics, not the discretisation); kept stable via
# νf·dt·λ_max < 2 for fixed homogeneous pure-EPI diffusion. A default step
# alone does not certify stability of an arbitrary configured model.
DT_CANONICAL = 1.0 / 2.0  # configured explicit step (tunable parameter)
DT_MIN_CANONICAL = 1.0 / 16.0  # configured subdivision floor when subdivision is active

# Selected scalar-chart clipping bounds; the nodal product does not derive them.
EPI_MAX_CANONICAL = 1.0  # unit form-magnitude bound
EPI_MIN_CANONICAL = -1.0  # unit form-magnitude bound (symmetric)

# Configured capacity bounds. A phase period is not a capacity upper bound.
# νf=0 freezes the unforced EPI channel; existing form need not disappear.
VF_MAX_CANONICAL = 2.0 * PI  # selected numeric ceiling in the configured time unit
VF_MIN_CANONICAL = 0.0  # inactive unforced EPI channel

# Coupling bounds: local coupling strength as π-fractions (tunable).
KL_MIN_CANONICAL = 1.0 / (8.0 * PI)  # minimum local coupling (tunable)
KL_MAX_CANONICAL = 1.0 / (2.0 * PI)  # maximum local coupling (tunable)

# Adaptation rates (tunable parameters; π-fractions).
UP_CANONICAL = 1.0 / (4.0 * PI)  # increment rate (tunable)
DOWN_CANONICAL = 1.0 / (2.0 * PI)  # decrement rate (tunable)

# Operator gain parameters (free magnitudes; contracts fix channel+sign).
AL_BOOST_CANONICAL = 0.10  # emission EPI increment (tunable; no energy identity)
VF_ADAPT_MU_CANONICAL = 0.10  # νf adaptation rate (tunable)

# Bifurcation thresholds (tunable parameters; midpoint of the unit range).
# Bifurcation-branch selector only. Direct ZHIR execution requires active νf
# and may be tightened separately through an explicit ZHIR_MIN_VF setting.
ZHIR_VF_THRESHOLD_CANONICAL = 0.5
NUL_EPI_THRESHOLD_CANONICAL = 0.5  # contraction safety EPI threshold (tunable)
# ZHIR's sampled positive-growth trigger.  This is an operational threshold,
# not a structural constant; centralizing it prevents runtime/SDK drift.
ZHIR_THRESHOLD_XI_CANONICAL = 0.1

# Configured selector hysteresis margin; not floating-point precision.
GLYPH_SELECTOR_MARGIN_CANONICAL = KL_MIN_CANONICAL  # = 1/(8π) (selected score margin)

# ============================================================================
# TOPOLOGY AND SPECTRAL CONSTANTS (Phase 3 Canonicalization)
# ============================================================================

# Topological factor bounds for k_top = 1/λ₁ (Fiedler-inverse relaxation scale).
# k_top itself is spectral (emergent); these are operational clamp rails.
K_TOP_MIN_CANONICAL = 1.0 / (8.0 * PI)  # 1/(8π) ≈ 0.040 (fast-relaxation floor)
K_TOP_MAX_CANONICAL = 1.0  # unit ceiling (star-graph normalization reference)
K_TOP_FALLBACK_CANONICAL = K_TOP_MAX_CANONICAL  # = 1.0 (disconnected graph → max-relaxation ceiling, consistent with the clamp)

THERAPEUTIC_EXCELLENT_CANONICAL = math.sin(
    PI / 3
)  # sin(π/3) ≈ 0.8660 (excellent therapeutic result)

# ============================================================================
# PHASE 4: STRUCTURAL OPERATORS CONSTANTS (Canonical Operator Replacements)
# ============================================================================

# Cycle Detection Balance target (selected policy: 1/(π+1))
CYCLE_OPTIMAL_BALANCE_CANONICAL = FRAGMENTATION_THRESHOLD  # 1/(π+1) ≈ 0.2415 (balance)
# Cycle rails, pattern weights, and algebra tolerances (operational knobs) →
# moved to tnfr.constants.operational (audit 2026).

# ============================================================================
# PHASE 5: MATHEMATICS AND PHYSICS CONSTANTS (Advanced Systems Canonicalization)
# ============================================================================

# Prime detection: prime ⟺ ΔNFR = 0 EXACTLY (canonical unit coefficients
# ζ=η=θ=1), and every composite has ΔNFR > 1 (the η·(τ−2) ≥ 1 term plus a
# positive σ-pressure). Any cut in (0, 1) separates them; 0.5 is the unit-gap
# midpoint — a structural separator, not a fitted value.
MATH_DELTA_NFR_THRESHOLD_CANONICAL = 0.5  # prime ⟺ ΔNFR = 0 separator (gap midpoint)
MATH_DELTA_NFR_THRESHOLD_2X_CANONICAL = (
    2.0 * MATH_DELTA_NFR_THRESHOLD_CANONICAL
)  # 1.0 (looser emergent-pattern band; composites still excluded, all > 1)

# PHYSICS_* network-study calibration knobs (operational) →
# moved to tnfr.constants.operational (audit 2026).

# Dynamics/Adelic Constants (temporal evolution and resonance)
DYNAMICS_ADELIC_DRIFT_CANONICAL = 0.1  # adelic drift (tunable)
DYNAMICS_ADELIC_DT_STEP_CANONICAL = 1.0 / 16.0  # adelic timestep = DT_MIN (tunable)

# Legacy compatibility value. Current adaptation reads SELECTOR_THRESHOLDS;
# this is not its default Si cut and must not act as a second fallback owner.
DYNAMICS_SI_HI_THRESHOLD_CANONICAL = (
    HIGH_COHERENCE_THRESHOLD  # π/(π+1) high-coherence Si gate
)

# ============================================================================
# PHASE 6: DYNAMICS MODULE CONSTANTS (Comprehensive Canonicalization)
# ============================================================================

# Integrators Constants (RK4 and numerical computation)
INTEGRATORS_RK4_SIXTH_CANONICAL = 6.0  # 6.0 (RK4 divisor: dt/6)
INTEGRATORS_HALF_STEP_CANONICAL = 2.0  # 2.0 (half-step divisor: dt/2)
INTEGRATORS_DNFR_BOUNDS_CANONICAL = 2.0  # 2.0 (ΔNFR bounds: max(-2,min(2,x)))
INTEGRATORS_CLIP_SOFT_K_CANONICAL = PI  # π ≈ 3.1416 (soft clipping K parameter)
INTEGRATORS_J_PHI_SCALE_CANONICAL = 0.1  # J_φ flux scaling factor (tunable)
INTEGRATORS_SYNTHETIC_DIV_CANONICAL = -0.15  # conservation coefficient (tunable)
INTEGRATORS_FLUX_FALLBACK_CANONICAL = 0.75  # neighbor flux fallback fraction (tunable)
INTEGRATORS_SIGMOID_OFFSET_CANONICAL = 0.5  # sigmoid coupling offset (unit midpoint)


# REMESH Operator Constants (structural memory)
REMESH_SIMILARITY_THRESHOLD_CANONICAL = UM_COMPAT_THRESHOLD  # π/(π+1) ≈ 0.7585 (structural similarity = high-coherence gate)


# Optimization-orchestrator, multi-modal-cache, and FFT-arithmetic knobs
# (operational) → moved to tnfr.constants.operational (audit 2026).

# Structural Feedback Loop Constants (homeostatic regulation)
# These replace inline magic numbers in dynamics/feedback.py. The control
# tolerances and rates are π-fractions on the coupling ladder (1/(2π), 1/(4π),
# 1/(8π)); the target coherence is the high-coherence gate π/(π+1).
FEEDBACK_COHERENCE_TOL_LOW = (
    COUPLING_MODERATE  # 1/(2π) ≈ 0.159 (low coherence tolerance)
)
FEEDBACK_COHERENCE_TOL_HIGH = (
    COUPLING_GENTLE  # 1/(4π) ≈ 0.0796 (high coherence tolerance)
)
FEEDBACK_DNFR_THRESHOLD = math.sqrt(
    FEEDBACK_COHERENCE_TOL_LOW * FEEDBACK_COHERENCE_TOL_HIGH
)  # √(1/(2π)·1/(4π)) = 1/(2π√2) ≈ 0.1125
FEEDBACK_EPI_THRESHOLD = 1.0 / 3.0  # 1/3 EPI threshold (tunable)
FEEDBACK_TARGET_COHERENCE = UM_COMPAT_THRESHOLD  # π/(π+1) ≈ 0.7585 (target coherence)
FEEDBACK_TAU_ADAPTIVE = COUPLING_MODERATE  # 1/(2π) ≈ 0.159 (adaptive-tau π-fraction)
FEEDBACK_LEARNING_RATE = (
    COUPLING_FINE  # 1/(8π) ≈ 0.0398 (feedback-loop gain, fine π-fraction)
)

# FFT, pattern-discovery, self-optimization, emergent-centralization, cache,
# unified-cache, integration, nodal-optimizer, and structural-cache knobs
# (operational, ~110 constants) → moved to tnfr.constants.operational (audit 2026).

# ============================================================================
# TELEMETRY DEFAULTS (selected diagnostic policies)
# ============================================================================

# --- Canonical Structural Field Tetrad Thresholds ---
# The phase maxima are π; their warning margins are selected policies.
# Potential thresholds are also policies: its linear pressure field has no
# universal phase-wrap bound. ξ_C has a fitted length and a spectral fallback.

# Φ_s: selected per-node safety value π/4, distinct from U6's drift policy π/2.
# A mathematical bound requires pressure and graph-kernel assumptions.
# The name retains VON_KOCH for code compatibility.
PHI_S_VON_KOCH_THRESHOLD: float = PI / 4  # π/4 ≈ 0.7854 (selected potential warning)

# |∇φ|: Phase Gradient Field — HEURISTIC early-warning level (audit 2026:
# NOT a derived bound; the kinematic bound is |∇φ| ≤ π (wrap), the SAME as K_φ;
# the sync-onset is σ-dependent ≈ 0.29, not a fixed constant).
GRAD_PHI_CANONICAL_THRESHOLD = (
    PI / 16
)  # π/16 ≈ 0.196 (heuristic |∇φ| early-warning, tunable)

# |K_φ|: selected 90% warning margin within the exact π wrap maximum.
K_PHI_CANONICAL_THRESHOLD = 0.9 * PI  # 0.9×π ≈ 2.8274

# ξ_C: Coherence Length Field (critical phenomena + RG)
XI_C_CRITICAL_RATIO = 1.0  # selected finite-size comparison with graph diameter
XI_C_WATCH_RATIO = PI  # selected watch multiplier for mean node eccentricity

# ============================================================================
# PHASE AND RESONANCE CONSTANTS
# ============================================================================

# Selected U3 admission ceiling, not the kinematic pi wrap bound. The runtime
# shared resolver may tighten it; admission alone does not imply phase motion.
DELTA_PHI_MAX = PI / 2  # π/2 ≈ 1.5708 rad (90° maximum phase mismatch for U3 coupling)
# Legacy exported trigonometric score cuts, currently not consumed by live
# phase admission. These dimensionless sine/cosine values are not angles.
PHASE_SYNC_THRESHOLD = math.sin(PI / 6)  # approximately 0.5, not 30 degrees
PHASE_DESYNC_LIMIT = math.cos(PI / 3)  # approximately 0.5, not 60 degrees
ANTIPHASE_THRESHOLD = math.cos(2 * PI / 3)  # approximately -0.5

# NOTE: the νf (structural-frequency) bounds are VF_MIN_CANONICAL = 0 and
# VF_MAX_CANONICAL = 2π (defined above). The former MIN/MAX_STRUCTURAL_FREQUENCY
# duplicated those (and were misused as a ΔNFR threshold) — removed (audit 2026).

# ============================================================================
# VALIDATION AND SAFETY CONSTANTS
# ============================================================================

# Grammar validation
# Selected U6 drift policy, not a phase-wrap theorem.
U6_STRUCTURAL_POTENTIAL_LIMIT = PI / 2
# Inert compatibility exports; current grammar/U3 consumers do not read these.
# In particular, U3 does not silently add a one-degree acceptance margin.
GRAMMAR_TOLERANCE = 1e-10
PHASE_VERIFICATION_TOLERANCE = PI / 180

# Legacy finite-comparison tolerance, currently unused. No finite tolerance
# decides convergence of an improper integral or supplies a tail bound.
INTEGRAL_CONVERGENCE_TOLERANCE = 1e-8
BIFURCATION_DETECTION_SENSITIVITY = 1e-6  # ∂²EPI/∂t² threshold detection
# Deprecated inert compatibility cut; no stability theorem.
COHERENCE_PRESERVATION_MINIMUM = 0.1

# Emergent-centralization, FFT-coordination, and cache-aware FFT knobs
# (operational) → moved to tnfr.constants.operational (audit 2026).

# ============================================================================
# PHASE 7: Physics Module Canonicalization (Fields & Interactions)
# ============================================================================

# Physics interactions thresholds
# Phase-gradient early-warning level (audit 2026: HEURISTIC, not derived —
# the kinematic |∇φ| bound is π (wrap); the sync-onset is σ-dependent).
PHASE_GRADIENT_THRESHOLD_CANONICAL = (
    GRAD_PHI_CANONICAL_THRESHOLD  # π/16 ≈ 0.196 heuristic |∇φ| early-warning (alias)
)
# Legacy alias for backward compatibility
PHYSICS_GRAD_THRESHOLD_CANONICAL = PHASE_GRADIENT_THRESHOLD_CANONICAL
PHYSICS_CURVATURE_HOTSPOT_CANONICAL = (
    K_PHI_CANONICAL_THRESHOLD  # 0.9×π ≈ 2.8274 (alias)
)
# Legacy Au-like permissive threshold: the midpoint between the selected
# 0.9·π warning level and the kinematic π wrap bound. The midpoint is exact
# once those endpoints are chosen, but it is an operational policy rather than
# a graph-independent physical derivation.
AU_CURVATURE_PERMISSIVE_THRESHOLD = (
    K_PHI_CANONICAL_THRESHOLD + PI
) / 2.0  # (0.9π+π)/2 = 0.95π ≈ 2.985 (permissive |K_φ|)
PHYSICS_HOTSPOT_FRACTION_CANONICAL = 0.1  # curvature-hotspot fraction warning (tunable)

# Operator pattern-scoring and domain-suitability weights (operational) →
# moved to tnfr.constants.operational (audit 2026).

# ============================================================================
# PHASE 7C: Mathematics Module Canonicalization
# ============================================================================

# Mathematics spectral-operator constants.  A Hermitian expectation is an
# auxiliary, unbounded observable; it is not canonical structural C(t).
MATH_SPECTRAL_EXPECTATION_FLOOR_DEFAULT = 0.1  # auxiliary default (tunable)
# Backward-compatible import alias.  New code must use the spectral name above.
MATH_COHERENCE_MIN_CANONICAL = MATH_SPECTRAL_EXPECTATION_FLOOR_DEFAULT
MATH_TOLERANCE_CANONICAL = 1.0e4  # numerical tolerance floor (operational)
MATH_PRECISION_ENHANCEMENT_CANONICAL = (
    MATH_TOLERANCE_CANONICAL / 100
)  # = 100.0 (machine-ε precision amplification factor)


# ============================================================================
# PHASE 7D: Configuration Module Canonicalization
# ============================================================================

# Config initialization canonical constants
CONFIG_INIT_VF_MEAN_CANONICAL = 0.5  # νf init mean (tunable)
CONFIG_INIT_VF_STD_CANONICAL = 0.15  # νf init stddev (tunable)

# Config thresholds canonical constants
CONFIG_EPI_LATENT_MAX_CANONICAL = 0.5  # AL emission max EPI for latent state (tunable)
CONFIG_VF_BASAL_CANONICAL = 0.5  # minimum νf for emission (tunable)
CONFIG_EPSILON_MIN_CANONICAL = 0.1  # minimum coherence gradient for AL (tunable)

"""Optional static arithmetic primality entry points.

This module exposes arithmetic primality utilities through a stable interface:
``is_prime``, ``delta_nfr``, ``component_breakdown``, ``structural_triad``, and
``analyze``.

The ``tnfr_primality`` external package is an **optional** dependency.
Importing this module always succeeds; errors are deferred until a function
is actually called without the dependency installed.
"""

from __future__ import annotations

import math
import numbers
from typing import Any

from .._optional_apps import bootstrap_application

__all__ = [
    "is_prime",
    "delta_nfr",
    "component_breakdown",
    "structural_triad",
    "analyze",
]


def _validate_candidate(n: int) -> int:
    """Validate a primality candidate without lossy coercion."""
    if isinstance(n, bool) or not isinstance(n, numbers.Integral):
        raise TypeError("n must be an integer, not a truncated numeric value")
    candidate = int(n)
    if candidate < 2:
        raise ValueError("n must be >= 2")
    return candidate


def _validate_tolerance(tolerance: float) -> float:
    """Validate a finite non-negative primality tolerance."""
    if isinstance(tolerance, bool) or isinstance(tolerance, (str, bytes)):
        raise TypeError("tolerance must be a finite non-negative real scalar")
    try:
        normalized = float(tolerance)
    except (TypeError, ValueError, OverflowError) as exc:
        raise TypeError("tolerance must be a finite non-negative real scalar") from exc
    if not math.isfinite(normalized) or normalized < 0.0:
        raise ValueError("tolerance must be finite and non-negative")
    return normalized


def _bootstrap_primality_test() -> None:
    """Ensure the tnfr_primality package is importable.

    In development checkouts the primality module lives in the
    ``applications/primality-test`` directory. When the standalone ``tnfr-primality``
    package is installed, this function becomes a no-op.
    """
    bootstrap_application("tnfr_primality", "primality-test")


def _load_core() -> tuple[Any, Any, Any, Any]:
    """Lazy-load core primality functions, raising clear errors if missing."""
    from ..errors import TNFRUserError

    _bootstrap_primality_test()
    try:
        from tnfr_primality import (
            tnfr_component_breakdown,
            tnfr_delta_nfr,
            tnfr_is_prime,
            tnfr_structural_triad,
        )

        return (
            tnfr_is_prime,
            tnfr_delta_nfr,
            tnfr_component_breakdown,
            tnfr_structural_triad,
        )
    except ModuleNotFoundError as exc:
        raise TNFRUserError(
            "tnfr_primality is not available. Install the tnfr-primality "
            "package or keep the applications/primality-test directory in your workspace."
        ) from exc


def delta_nfr(n: int) -> float:
    """Compute arithmetic TNFR pressure $\\Delta NFR(n)$."""
    n = _validate_candidate(n)
    _, tnfr_delta_nfr, _, _ = _load_core()
    return float(tnfr_delta_nfr(n))


def is_prime(n: int, *, tolerance: float = 1e-10) -> tuple[bool, float]:
    """Run TNFR primality test and return ``(is_prime, delta_nfr)``."""
    n = _validate_candidate(n)
    tolerance = _validate_tolerance(tolerance)
    tnfr_is_prime, _, _, _ = _load_core()
    result, dnfr = tnfr_is_prime(n, tolerance=tolerance)
    return bool(result), float(dnfr)


def component_breakdown(n: int) -> dict[str, Any]:
    """Return per-component $\\Delta NFR$ decomposition."""
    n = _validate_candidate(n)
    _, _, tnfr_component_breakdown, _ = _load_core()
    return dict(tnfr_component_breakdown(n))


def structural_triad(n: int) -> dict[str, Any]:
    """Return a static arithmetic bundle; its legacy name does not supply phase."""
    n = _validate_candidate(n)
    _, _, _, tnfr_structural_triad = _load_core()
    return dict(tnfr_structural_triad(n))


def analyze(n: int, *, tolerance: float = 1e-10) -> dict[str, Any]:
    """Return static arithmetic primality analysis for SDK/reporting."""
    n = _validate_candidate(n)
    tolerance = _validate_tolerance(tolerance)
    prime, dnfr = is_prime(n, tolerance=tolerance)
    breakdown = component_breakdown(n)
    triad = structural_triad(n)
    return {
        "n": int(n),
        "is_prime": bool(prime),
        "delta_nfr": float(dnfr),
        "components": breakdown,
        "triad": triad,
        "tolerance": float(tolerance),
    }

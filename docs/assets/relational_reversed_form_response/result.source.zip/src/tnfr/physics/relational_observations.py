"""Read-only regional observations of the selected relational exchange model.

An explicit reference supplies real phase lifts, not a discovered equilibrium.
The full centered form and phase-error vectors retain information discarded by
regional means. Shared winding and transport observations add no evolution,
identity certificate, reduced closure or automatic selection policy.
"""

from __future__ import annotations

from collections.abc import Mapping, Set
from dataclasses import dataclass
from fractions import Fraction
from typing import Any

import networkx as nx

from .._exact_time import finite_represented_real
from ..constants.aliases import ALIAS_DNFR, ALIAS_EPI, ALIAS_THETA, ALIAS_VF
from ..dynamics.relational import (
    RelationalExchangeField,
    RelationalExchangeModel,
    evaluate_relational_exchange,
)
from .support_transport import (
    RegionalSupportBalance,
    observe_regional_support_balance,
    observe_support_transport,
)
from .winding_certificates import WindingCertificate, certify_phase_winding

__all__ = (
    "RegionalPatternObservation",
    "RelationalPatternObservation",
    "observe_relational_pattern",
)


@dataclass(frozen=True)
class RegionalPatternObservation:
    """One supplied region's complete centered coordinates and separate offsets.

    Means are arithmetic means, whereas ``transport.mean`` uses the shared
    degree/capacity metric. The two squared norms have their respective form
    and phase units; no combined metric or recovery threshold is introduced.
    """

    nodes: tuple[Any, ...]
    form_mean: Fraction
    phase_error_mean: Fraction
    centered_form: tuple[Fraction, ...]
    centered_phase_error: tuple[Fraction, ...]
    form_norm_squared: Fraction
    phase_norm_squared: Fraction
    transport: RegionalSupportBalance | None
    transport_unavailable_reason: str | None


@dataclass(frozen=True)
class RelationalPatternObservation:
    """Detached fresh field and observations in caller-supplied regional frames.

    ``reference_phase`` follows ``field.nodes`` and contains materialized real
    lifts. Subtracting them does not wrap angles or infer a common semicircle.
    A common change of phase offset disappears on centering; independently
    changing node representatives by full turns changes the supplied frame.
    """

    field: RelationalExchangeField
    reference_phase: tuple[float, ...]
    regions: tuple[RegionalPatternObservation, ...]
    winding: tuple[WindingCertificate, ...]
    scope: tuple[str, ...] = (
        "one_fresh_detached_relational_field_without_live_graph_writes",
        "supplied_real_reference_lifts_and_ordered_possibly_overlapping_regions",
        "exact_rational_centering_of_materialized_form_and_phase_coordinates",
        "separate_form_and_phase_units_without_a_combined_norm_or_threshold",
        "regional_transport_uses_full_support_and_independent_phase_source",
        "declared_cycle_winding_is_snapshot_geometry_not_temporal_identity",
        "no_reference_equilibrium_recovery_formation_closed_reduction_or_selection_certificate",
    )


def _ordered(value, label):
    if isinstance(value, (str, bytes, bytearray, Mapping, Set)):
        raise TypeError(f"{label} must be an ordered iterable")
    try:
        return tuple(value)
    except TypeError as exc:
        raise TypeError(f"{label} must be an ordered iterable") from exc


def _regions(nodes, regions):
    raw = _ordered(regions, "regions")
    if not raw:
        raise ValueError("regions must contain at least one region")
    lookup = {node: index for index, node in enumerate(nodes)}
    result = []
    for region in raw:
        row = _ordered(region, "region")
        if not row:
            raise ValueError("each region must be nonempty")
        try:
            indices = tuple(lookup[node] for node in row)
        except (TypeError, KeyError) as exc:
            raise ValueError("region nodes must belong to the full support") from exc
        if len(set(indices)) != len(indices):
            raise ValueError("region nodes must be distinct")
        result.append(indices)
    return tuple(result)


def _detached_graph(field):
    """Rebuild only the captured state consumed by the existing observers."""
    graph = nx.Graph()
    for i, node in enumerate(field.nodes):
        graph.add_node(
            node,
            **{
                ALIAS_EPI[0]: field.epi[i],
                ALIAS_VF[0]: field.capacity[i],
                ALIAS_THETA[0]: field.phase[i],
                ALIAS_DNFR[0]: field.pressure[i],
            },
        )
    graph.add_edges_from((a, b, {"weight": 1.0}) for a, b in field.edges)
    return graph


def observe_relational_pattern(
    graph,
    *,
    model: RelationalExchangeModel,
    reference_phase: Mapping,
    regions,
    cycles=(),
) -> RelationalPatternObservation:
    """Observe supplied regions using exactly one fresh relational evaluation.

    Reference phases must map the exact full node support to finite represented
    real lifts. Regions are ordered, nonempty selections without repeated nodes;
    they may overlap and need not partition support. No reference equilibrium,
    lift compatibility over time or automatic regional discovery is inferred.

    Transport is unavailable if any full-support capacity is zero, EPI weight
    is zero, or the region covers all support (in that order of precedence).
    Those are limitations of the existing regional transport contract, not
    failures of the retained geometry. Its forcing is independently supplied
    as ``w*phase_source``; native pressure-split defects are retained.

    Optional ordered cycles delegate geometric availability to the existing
    winding owner. No observation advances a graph or certifies a trajectory.
    """
    field = evaluate_relational_exchange(graph, model=model)
    if not isinstance(reference_phase, Mapping):
        raise TypeError("reference_phase must map the exact full node support")
    if set(reference_phase) != set(field.nodes):
        raise ValueError("reference_phase must match the exact full node support")
    reference = tuple(
        finite_represented_real(reference_phase[node], "reference phase")[0]
        for node in field.nodes
    )
    selections = _regions(field.nodes, regions)
    ordered_cycles = tuple(
        _ordered(cycle, "cycle") for cycle in _ordered(cycles, "cycles")
    )
    detached = _detached_graph(field)
    unavailable = (
        "zero_capacity_in_full_support"
        if any(capacity == 0.0 for capacity in field.capacity)
        else ("zero_epi_weight" if model.epi_weight == 0.0 else None)
    )
    source = (
        observe_support_transport(detached)
        if unavailable is None
        and any(len(row) < len(field.nodes) for row in selections)
        else None
    )
    forcing = tuple(
        Fraction(model.phase_weight) * Fraction(value) for value in field.phase_source
    )
    observed = []
    for indices in selections:
        nodes = tuple(field.nodes[i] for i in indices)
        form = tuple(Fraction(field.epi[i]) for i in indices)
        error = tuple(
            Fraction(field.phase[i]) - Fraction(reference[i]) for i in indices
        )
        form_mean, phase_mean = sum(form) / len(form), sum(error) / len(error)
        centered_form = tuple(value - form_mean for value in form)
        centered_phase = tuple(value - phase_mean for value in error)
        reason = unavailable or (
            "full_support_region" if len(indices) == len(field.nodes) else None
        )
        transport = (
            observe_regional_support_balance(
                source, nodes, epi_weight=Fraction(model.epi_weight), forcing=forcing
            )
            if reason is None
            else None
        )
        observed.append(
            RegionalPatternObservation(
                nodes=nodes,
                form_mean=form_mean,
                phase_error_mean=phase_mean,
                centered_form=centered_form,
                centered_phase_error=centered_phase,
                form_norm_squared=sum(
                    (value**2 for value in centered_form), Fraction(0)
                ),
                phase_norm_squared=sum(
                    (value**2 for value in centered_phase), Fraction(0)
                ),
                transport=transport,
                transport_unavailable_reason=reason,
            )
        )
    return RelationalPatternObservation(
        field=field,
        reference_phase=reference,
        regions=tuple(observed),
        winding=tuple(
            certify_phase_winding(detached, cycle) for cycle in ordered_cycles
        ),
    )

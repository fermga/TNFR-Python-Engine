"""Freeze, then evaluate exactly one retained-parent canonical UM endpoint."""

from __future__ import annotations

import platform
import subprocess
import sys
import traceback
from datetime import datetime, timezone
from fractions import Fraction as Q
from importlib.metadata import version
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(r"C:\TNFR-Python-Engine")
sys.path.insert(0, str(ROOT / "src"))

from tnfr.research.artifact_io import (
    decode_exact_tree,
    encode_exact_tree,
    file_receipt,
    read_bytes_bounded,
    sha256_bytes,
    validate_artifact_path,
    verify_archive_members,
    write_json_once,
)
from tnfr.research.local_capacity_history import encode_result, TIMES
from tnfr.research.maintained_parent_thol import _signature
from tnfr.research.maintained_parent_um_source import load_thol_successor
from tnfr.research.maintained_parent_um_work import predict_parent_um_work
from tnfr.research.maintained_successor_motion import predict_successor_motion
from tnfr.research.retained_graph_state import (
    record_graph_state,
    restore_recorded_graph_state,
)
from tnfr.utils.io import json_dumps, json_loads

OUT = ROOT / "docs/assets/maintained_parent_um_execution"
MOTION = ROOT / "docs/assets/successor_nonstationary"


def read(path):
    return decode_exact_tree(
        json_loads(read_bytes_bounded(path, max_bytes=32 * 1024**2))
    )


def write(name, value):
    write_json_once(OUT / name, encode_result(value))


def same_projection(left, right):
    return json_dumps(
        encode_exact_tree(encode_result(left)), sort_keys=True
    ) == json_dumps(encode_exact_tree(encode_result(right)), sort_keys=True)


def receipt(path, label=None):
    return file_receipt(path, label=label or path.relative_to(ROOT).as_posix())


def verify_rows(base, rows):
    for row in rows:
        name = validate_artifact_path(row["path"])
        path = (base / name).resolve()
        if not path.is_relative_to(base.resolve()):
            raise ValueError("artifact escaped its declared root")
        if receipt(path, name) != row:
            raise ValueError(f"frozen artifact differs: {name}")


def source():
    return load_thol_successor(
        ROOT / "docs/assets/maintained_parent_thol", repository_root=ROOT
    )


def bind_motion(prediction):
    """Bind primitives to the existing theorem; never run its producer."""
    frozen = read(MOTION / "freeze.json")
    verify_rows(MOTION, frozen["artifacts"])
    manifest = read(MOTION / "source-manifest.json")
    verify_archive_members(
        MOTION / "source.zip",
        {row["path"]: row["sha256"] for row in manifest["files"]},
    )
    original_source = read(MOTION / "source.json")
    if not same_projection(prediction, original_source["prediction"]):
        raise ValueError("current conditional family differs from the archived theorem")
    if not same_projection(
        prediction.conditional.epi + prediction.conditional.phases,
        original_source["initial_box"],
    ):
        raise ValueError(
            "archived initial box differs from complete source coordinates"
        )
    protocol = read(MOTION / "protocol.json")
    if (
        protocol["horizon"] != Q(1, 2)
        or protocol["step"] != Q(1, 512)
        or type(protocol["maximum_steps"]) is not int
        or protocol["maximum_steps"] != 256
        or type(protocol["order"]) is not int
        or protocol["order"] != 12
    ):
        raise ValueError("inherited motion protocol differs")
    attempt, result = read(MOTION / "attempt.json"), read(MOTION / "result.json")
    if attempt["freeze"] != receipt(MOTION / "freeze.json", "freeze.json"):
        raise ValueError("motion attempt association differs")
    if result["attempt"] != receipt(MOTION / "attempt.json", "attempt.json"):
        raise ValueError("motion result association differs")
    report = result["report"]
    if (
        report["status"] != "completed"
        or type(report["accepted_steps"]) is not int
        or report["accepted_steps"] != 256
        or type(report["attempted_steps"]) is not int
        or report["attempted_steps"] != 256
        or report["certified_retention_time"] != Q(1, 2)
        or any(
            report[key] is not True
            for key in (
                "full_horizon_retention",
                "reversal_certified",
                "joint_target_certified",
            )
        )
        or len(result["records"]) != 256
        or tuple(row["artifact"]["path"] for row in result["records"])
        != tuple(f"steps/{index:03d}.zip" for index in range(256))
    ):
        raise ValueError("retained motion completion or step inventory differs")
    # All per-step contents/inequalities have their independent read-only test
    # owner; retain every exact artifact association without regenerating jets.
    for row in result["records"]:
        verify_rows(MOTION, (row["artifact"],))
        verify_archive_members(
            MOTION / row["artifact"]["path"],
            {row["member"]["path"]: row["member"]["sha256"]},
        )
    return tuple(
        receipt(MOTION / name)
        for name in ("freeze.json", "source.json", "attempt.json", "result.json")
    )


def freeze():
    admitted = source()
    prediction = predict_successor_motion(admitted.graph)
    motion_receipts = bind_motion(prediction)
    work = predict_parent_um_work(admitted.graph)
    OUT.mkdir(parents=True, exist_ok=False)
    write(
        "protocol.json",
        {
            "schema": "tnfr.maintained-parent-um-execution-protocol.v1",
            "evaluation_status_at_freeze": "not_evaluated",
            "question": "Does the actual canonical UM endpoint enter the previously certified conditional family?",
            "source": "retained actual THOL successor, re-admitted from primitive history and birth evidence",
            "target_order": (2,),
            "seed": 17,
            "word_context": ("VAL", "THOL", "UM", "SHA"),
            "step_index": 2,
            "operation": "one shared atomic Coupling stage with all default branches, all-candidate count zero, strict gates, rejection by raising",
            "clock": "unchanged structural time, zero-duration hybrid reset; subsequent elapsed structural t",
            "structural_time": TIMES[-1],
            "event_metadata_timestamp": "2030-01-02T03:04:07+00:00",
            "maximum_events": 1,
            "maximum_trajectories": 0,
            "maximum_attempts": 1,
            "numerics": "binary64 canonical event; independently rebuilt exact rational/dyadic interval checks",
            "reset_error_allowance": prediction.chamber.reset.numerical_allowance,
            "pressure_refresh_error_allowance": Q(1, 2**46),
            "law": "x_dot=M*S(theta); theta_dot=M*L_W*x; M=diag(nu/(pi*d)); held support/weights/positive capacities, no Gamma or loss",
            "pressure": "raw operator relief recorded separately; independently refreshed bare-neighbor sine pressure",
            "acceptance": (
                "exact retained before-state and one canonical parent stage, with live grammar",
                "all21 nodes/forms and45 old edge payloads unchanged; exactly8 predicted new edges",
                "only predicted phases/capacity change; maximum distance to both ideal interval endpoints <=2^-40 for each changed phase/capacity/weight",
                "raw parent pressure within prospective allowance; other raw pressures unchanged",
                "pressure-only callback, with separate later stage metadata; fresh pressure error <=2^-46",
                "all primitive coordinates/held parameters in the exact archived conditional family; all53 branch integers match",
                "complete event work from old-edge phase and new-edge form/phase, with actual means and both continued rows",
                "preserved hierarchy, temporal samples, structural clock and declared parent-only glyph/lifecycle changes; no child baseline",
            ),
            "transfer": "Existing [0,1/2] all-branch retention and relative-velocity reversal apply only after primitive inclusion and identical complete-law admission",
            "scope": "One supplied UM occurrence; incomplete VAL,THOL,UM prefix. No SHA, IL, autonomous event law, reservoir, universal organization or physical identification.",
            "stop": "retain the single positive, negative or unavailable result; no retries, tuned defaults, weakened allowance or regenerated motion",
        },
    )
    write(
        "source.json",
        {
            "schema": "tnfr.maintained-parent-um-execution-source.v1",
            "before": record_graph_state(admitted.graph),
            "motion_prediction": prediction,
            "work_prediction": work,
            "existing_motion_receipts": motion_receipts,
            "retained_source_receipts": admitted.receipts,
        },
    )
    files = {
        path.relative_to(ROOT).as_posix(): path.read_bytes()
        for path in sorted((ROOT / "src/tnfr").rglob("*.py"))
    }
    files["pyproject.toml"] = (ROOT / "pyproject.toml").read_bytes()
    files["instrument.py"] = Path(__file__).read_bytes()
    write(
        "source-manifest.json",
        {
            "schema": "tnfr.source-manifest.v1",
            "files": [
                {"path": name, "bytes": len(raw), "sha256": sha256_bytes(raw)}
                for name, raw in sorted(files.items())
            ],
        },
    )
    with ZipFile(OUT / "source.zip", "x", compression=ZIP_DEFLATED) as archive:
        for name, raw in sorted(files.items()):
            archive.writestr(name, raw)
    prior = [
        receipt(path)
        for path in sorted((ROOT / "docs/assets").rglob("*"))
        if path.is_file() and not path.is_relative_to(OUT)
    ]
    write(
        "freeze.json",
        {
            "schema": "tnfr.maintained-parent-um-execution-freeze.v1",
            "evaluation_status_at_freeze": "not_evaluated",
            "git_base": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT)
            .decode()
            .strip(),
            "source_policy": "complete current Python source, including uncommitted work",
            "artifacts": [
                receipt(OUT / name, name)
                for name in (
                    "protocol.json",
                    "source.json",
                    "source-manifest.json",
                    "source.zip",
                )
            ],
            "prior_artifacts": prior,
        },
    )
    print(
        f"FROZEN: {len(files)} source files, {len(prior)} unchanged prior assets; UM not executed",
        flush=True,
    )


def check_frozen():
    frozen = read(OUT / "freeze.json")
    verify_rows(OUT, frozen["artifacts"])
    verify_rows(ROOT, frozen["prior_artifacts"])
    manifest = read(OUT / "source-manifest.json")
    verify_archive_members(
        OUT / "source.zip", {r["path"]: r["sha256"] for r in manifest["files"]}
    )
    for row in manifest["files"]:
        path = Path(__file__) if row["path"] == "instrument.py" else ROOT / row["path"]
        if receipt(path, row["path"]) != row:
            raise ValueError(f"live source differs from freeze: {row['path']}")


def evaluate():
    from tnfr.research.maintained_parent_um_execution import (
        evaluate_um_event,
        check_um_endpoint,
    )

    if any(
        (OUT / name).exists()
        for name in (
            "attempt.json",
            "raw-after.json",
            "response.json",
            "report.json",
            "failure.json",
        )
    ):
        raise FileExistsError("a retained attempt prevents another UM evaluation")
    check_frozen()
    admitted = source()
    frozen_source = read(OUT / "source.json")
    prediction = predict_successor_motion(admitted.graph)
    frozen_graph = restore_recorded_graph_state(frozen_source["before"]).graph
    if (
        _signature(admitted.graph) != _signature(frozen_graph)
        or not same_projection(prediction, frozen_source["motion_prediction"])
        or not same_projection(
            predict_parent_um_work(admitted.graph), frozen_source["work_prediction"]
        )
    ):
        raise ValueError("source or prospective prediction changed after freeze")
    bind_motion(prediction)
    write(
        "attempt.json",
        {
            "schema": "tnfr.maintained-parent-um-execution-attempt.v1",
            "freeze": receipt(OUT / "freeze.json", "freeze.json"),
            "evaluation_status_at_start": "not_evaluated",
            "attempt_number": 1,
            "created_utc": datetime.now(timezone.utc).isoformat(),
            "python": sys.version,
            "platform": platform.platform(),
            "versions": {
                name: version(name) for name in ("numpy", "networkx", "mpmath")
            },
            "seed": 17,
            "backend": "Python binary64 event / exact rational dyadic interval admission",
        },
    )
    try:
        response = evaluate_um_event(
            admitted,
            frozen_before=frozen_source["before"],
            prediction=prediction,
            on_raw=lambda raw: write("raw-after.json", raw),
        )
        write("response.json", response)
        graphs = [
            restore_recorded_graph_state(response[name]).graph
            for name in ("before", "raw_after", "endpoint")
        ]
        assessment = check_um_endpoint(
            *graphs, prediction=prediction, stage=response["stage"]
        )
        check_frozen()
        write(
            "report.json",
            {
                "schema": "tnfr.maintained-parent-um-execution-report.v1",
                "attempt": receipt(OUT / "attempt.json", "attempt.json"),
                "response": receipt(OUT / "response.json", "response.json"),
                "raw_after": receipt(OUT / "raw-after.json", "raw-after.json"),
                "assessment": assessment,
            },
        )
        checks = assessment["checks"]
        print(f"UM checks: {sum(checks.values())}/{len(checks)}", flush=True)
        print(
            f"Failed checks: {[name for name, passed in checks.items() if not passed]}",
            flush=True,
        )
        return 0 if all(checks.values()) else 1
    except BaseException:
        diagnostic = traceback.format_exc()
        write(
            "failure.json",
            {
                "schema": "tnfr.maintained-parent-um-execution-failure.v1",
                "attempt": receipt(OUT / "attempt.json", "attempt.json"),
                "diagnostic": diagnostic,
            },
        )
        try:
            write("failure-endpoint.json", record_graph_state(admitted.graph))
        except BaseException:
            write(
                "failure-endpoint-diagnostic.json",
                {"diagnostic": traceback.format_exc()},
            )
        raise


if __name__ == "__main__":
    result = {"freeze": freeze, "evaluate": evaluate}[sys.argv[1]]()
    raise SystemExit(result or 0)

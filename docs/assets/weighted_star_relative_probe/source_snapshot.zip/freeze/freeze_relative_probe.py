"""One admission freeze. This driver never computes the reserved response.

Run from the repository root with its Python environment. Unchanged exact
committed bytes are identified by base revision/blob; only changed/untracked
source bytes are archived. The archive also retains this one-use driver.
"""

import hashlib
import importlib.metadata
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from tnfr.research.artifact_io import (
    decode_exact_tree,
    file_receipt,
    read_bytes_bounded,
    sha256_bytes,
    verify_archive_members,
    write_json_once,
)
from tnfr.research.weighted_star_relative_probe import (
    prepare_weighted_star_relative_probe,
)
from tnfr.research.weighted_star_relative_probe_protocol import (
    assess_relative_probe_protocol,
    frozen_protocol,
)
from tnfr.utils.io import json_loads

root = Path.cwd().resolve(strict=True)
target = root / "docs/assets/weighted_star_relative_probe"
if target.exists():
    raise RuntimeError("freeze target already exists; do not overwrite or retry")
source_name = "docs/assets/weighted_star_registration_episode/preparation.json"
original = decode_exact_tree(
    json_loads(read_bytes_bounded(root / source_name, max_bytes=256 * 1024))
)
protocol = frozen_protocol()
# Only these newly admitted canonical words execute. No prior producer or
# finite continuation is invoked.
prepared = prepare_weighted_star_relative_probe(original)
admission = assess_relative_probe_protocol(original, prepared.record, protocol)
assert admission["reserved_response_evaluated"] is False

revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
tree = subprocess.check_output(["git", "ls-tree", "-r", "-z", revision])
base = {}
for entry in tree.split(b"\0"):
    if entry:
        metadata, name = entry.split(b"\t", 1)
        mode, kind, blob = metadata.decode("ascii").split()
        if kind == "blob" and mode in ("100644", "100755"):
            base[name.decode("utf-8")] = blob

sources = {
    path.relative_to(root).as_posix(): path
    for path in (root / "src/tnfr").rglob("*")
    if path.is_file()
    and "__pycache__" not in path.parts
    and (path.suffix in (".py", ".pyi", ".json") or path.name == "py.typed")
}
for name in (
    "pyproject.toml",
    "AGENTS.md",
    "theory/EMERGENT_ONTOLOGY.md",
    "theory/UNIFIED_GRAMMAR_RULES.md",
    "theory/STRUCTURAL_OPERATORS.md",
    "theory/nodal/RELATION_FOUNDATIONS.md",
    "theory/research/RELATIVE_COUPLING_PROBE.md",
    "tests/research/test_weighted_star_relative_probe.py",
    "tests/research/test_weighted_star_relative_probe_protocol.py",
    "tests/research/test_weighted_star_relative_probe_evidence.py",
):
    sources[name] = root / name
sources["freeze/freeze_relative_probe.py"] = Path(__file__).resolve(strict=True)
inventory, overlay = {}, {}
for name, path in sorted(sources.items()):
    if path.is_symlink():
        raise RuntimeError("source symlinks are not admitted")
    data = read_bytes_bounded(path, max_bytes=8 * 1024**2)
    item = {"bytes": len(data), "sha256": sha256_bytes(data)}
    git_blob = hashlib.sha1(
        b"blob " + str(len(data)).encode("ascii") + b"\0" + data
    ).hexdigest()
    if base.get(name) == git_blob:
        item.update(recovery="git_blob", git_blob=git_blob)
    else:
        item.update(recovery="source_snapshot.zip")
        overlay[name] = data
    inventory[name] = item

target.mkdir()
for name, payload in (
    ("protocol.json", protocol),
    ("preparation.json", prepared.record),
    ("admission.json", admission),
):
    write_json_once(target / name, payload, sort_keys=True, base_dir=target)
archive_path = target / "source_snapshot.zip"
with ZipFile(archive_path, mode="x", compression=ZIP_DEFLATED) as archive:
    for name, data in overlay.items():
        info = ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, data)
verify_archive_members(
    archive_path, {name: sha256_bytes(data) for name, data in overlay.items()}
)
packages = {}
for name in ("numpy", "networkx", "scipy", "sympy", "tnfr"):
    try:
        packages[name] = importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        packages[name] = "distribution metadata unavailable"
manifest = {
    "schema": "tnfr.weighted-star-relative-probe.freeze.v1",
    "status": "admitted; reserved_response_not_evaluated",
    "response_evaluated": False,
    "recorded_at": datetime.now(timezone.utc).isoformat(),
    "recorded_at_scope": "local metadata; not trusted chronology",
    "git_base_revision": revision,
    "source_scope": "all src/tnfr Python/schema/type files; listed contract/proof/test owners",
    "source_recovery": "exact base git blobs plus byte-preserving changed/untracked overlay; no newline normalization",
    "source_inventory": inventory,
    "original_preparation": file_receipt(root / source_name, label=source_name),
    "artifacts": {
        name: file_receipt(target / name, label=name)
        for name in (
            "protocol.json",
            "preparation.json",
            "admission.json",
            "source_snapshot.zip",
        )
    },
    "environment": {
        "python": sys.version,
        "implementation": platform.python_implementation(),
        "platform": platform.platform(),
        "packages": packages,
        "dependency_scope": "versions recorded; third-party binaries not archived",
    },
    "execution": {
        "word_execution": "four independent canonical AL/SHA words; no old producer replay",
        "source_configuration": "retained in all complete prefix records",
        "node_order": list(range(10)),
        "precision": "exact represented inputs; rational static bounds; no numerical response",
        "association_scope": "byte and scientific consistency; not authentication",
    },
}
write_json_once(target / "manifest.json", manifest, sort_keys=True, base_dir=target)
print(
    f"Frozen {len(inventory)} source entries; {len(overlay)} changed/untracked overlay members."
)
print(f"Source archive bytes: {archive_path.stat().st_size}")
print("Reserved response: not evaluated.")

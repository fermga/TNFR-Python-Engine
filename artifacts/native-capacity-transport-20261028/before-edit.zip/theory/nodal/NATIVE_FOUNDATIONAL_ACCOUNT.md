# Native C5 foundation account and dynamic-capacity admission

<a id="native-foundational-account"></a>

This account applies the [four foundation prerequisites](../RESEARCH_PROGRAM.md#foundational-pillars)
to one provisional realization. Its structural capability is retention of a
nonuniform organization and a reproducible response to small perturbations.
It does not require a permanent pulse. The existing native reciprocal law is
the reference; releasing held capacity is an explicitly supplied comparison.
Definitions, previous proofs and new joint-model claims are distinguished
below. No foundational pillar or physical identification is closed by this
single example.

## 1. Why this reference, and what the alternatives retain

| Candidate | Useful capability and independent premises | Decision for this account |
| --- | --- | --- |
| Native relational C5 | Existing native pressure, a conditional reciprocal phase row, positive capacities and a strict winding-one geometry with proved local recovery | Selected because it provides a complete, implemented reference and an identity distinct from a periodic scalar signal. |
| Normalized-sine law | Global smooth pressure and mobility supplied by a different constitutive law; extensive pulse and collective results | Retained alternative. Another property of a periodic branch would not resolve the present causal premise. |
| Ordinary native hybrid runtime | Registered actions, stored pressure, histories, diagnostics, gains, target order and an outer decision schedule | Retained for operator-occurrence questions. Disabling glyphs does not turn this execution path into the relational law. |
| Threshold Emission/Coherence/Silence completion | A supplied autonomous guard with actual primary maps and a known loss of pressure/capacity | Retained countermodel separating occurrence from maintenance; its existing obstruction is not evaluated again. |

This selects an instrument for the stated capability, not a uniquely correct
TNFR law. The [native admission](RELATIONAL_EXCHANGE_ADMISSION.md),
[sine distinction](SINE_CONSTITUTIVE_INFORMATION.md), [hybrid occurrence audit](../NATIVE_OPERATOR_DYNAMICS.md#native-selector-clock-admission)
and [threshold result](OPERATOR_PULSE_CLOSURE.md#operator-pulse-causal-closure)
retain their separate scopes. The [native recovery theorem](RELATIONAL_RECOVERY_AND_INTERACTION.md#relational-local-recovery)
admits a simple-cycle twist only when `|ell|<n/4`; C5 is the smallest
simple cycle with a nonzero strictly acute twist in this class, not a
universally minimal NFR.

## 2. Complete reference and sufficient state

Use the fixed labeled unit C5, no loops or inputs, signed dimensionless form
`x`, circular primitive phase `theta`, and positive capacity `nu`.
Let `B=2I-A`, `L=B/2` and `N=diag(nu)`. Effective coefficients
`e,w>0`, `e+w=1`, and `beta>0` are fixed independently of a response.
Time is a declared structural parameter. In this normalized form chart,
capacity and the coefficient `kappa` have inverse-clock units; `nu_dot` has
inverse-clock-squared units. The comparison below fixes `e=w=1/2, beta=1`.

On the native regular chart, write the relative resultant
`z_i=sum_(j~i) exp(i*(theta_j-theta_i))`,
`g_i=Arg(z_i)/pi` and
`H_i=pi*abs(z_i)*sinc(Arg(z_i))>0`, with `sinc(0)=1`.
The selected two-channel pressure and reference rows are

```text
p = P(x,theta) = -e*L*x + w*g(theta),
x_dot = N*p,
theta_dot = (w/beta)*H(theta)^(-1)*N*B*x,
nu_dot = 0.
```

The native phase metric and source use the same relative resultant.
The reciprocal phase row follows conditionally from the independently
specified joint storage and exchange premise, or the alternative locality
and capacity hypotheses in the admission owner. It does not follow from
`x_dot=nu*p` alone.

| Item | Role and retained information |
| --- | --- |
| Form and phase | Independent coordinates of this realization. A scalar form reader is not the full predictive state. |
| Capacity | A positive held input in the reference. It becomes a coordinate with an explicit row in the comparison below. |
| Pressure | A function of form, phase and fixed model data; no capacity-contrast pressure channel or independent pressure coordinate is added. |
| Graph, coefficients and clock | Supplied premises, not emergent geometry or a laboratory calibration. |
| Boundary and history | The five-node system is closed. There is no external environment, consumed history, selector or event schedule in these rows. |
| Observations | Raw form/phase/capacity, pressure, rates and winding have different roles. Absolute-output predictions retain origins; a quotient prediction must specify the omitted common offsets. |

A graph snapshot is a sufficient mathematical state only together with this
complete law and an admitted continuation. The local theorem below concerns
a neighborhood in which the field is smooth and the phase chart persists;
it does not license arbitrary singular or nonacute preparations.

The existing [field evaluator and executor](../../src/tnfr/dynamics/relational.py)
provide the held-capacity implementation. The evaluator supplies an
instantaneous field; the executor is an admitted explicit Euler step, not an
exact trajectory. The dynamic-capacity comparison below is not installed by
changing capacities between executor calls or disabling native glyphs.

## 3. Identity, observations and operator roles

The reference equilibrium has `x=c*1`,
`theta_i=2*pi*i/5+alpha` modulo `2*pi`, and positive held capacities.
Its nonuniform phase geometry has winding one. Small joint perturbations,
rather than a prescribed periodic signal, test retention and response.
Common form and phase origins are symmetries; their actual means need not
be conserved during a response. Retention of the winding geometry is weaker
than recovery to its equilibrium shape, and neither establishes acquisition
from a state lacking that identity.

The continuous form/phase exchange is a supplied constitutive mechanism in
this account. Registered jumps are available interventions under their own
contracts; they are not hidden commands executing these differential rows.
No autonomous invocation of all thirteen operators, support birth or capacity
replenishment is inferred. The [causal-role owner](../STRUCTURAL_OPERATORS.md#operator-causal-role)
retains the stronger proposal that an organization could realize an effective
named action.

Several tempting first discriminators are already settled and are reused as
constraints, not new results:

- The native decision schedule and selector memory affect occurrence.
- A pressure-only Coherence write can be erased by constitutive refresh.
- Public/staged Coherence also changes phase and fresh neighboring pressures;
  its full [handoff](SINE_COLLECTIVE_PRESSURE_HANDOFF.md) and
  [state boundary](SINE_PRESSURE_COMPLETION.md) already distinguish those effects.
- The declared Emission/Coherence/Silence cycle lacks the required restoration.
- Native C5 local recovery and insufficiency of arbitrary aggregate observations
  have existing proof owners.

The remaining scoped question is whether positive capacity must stay fixed
for this particular joint identity and response, or whether a declared
autonomous evolution of that property is compatible with them.

## 4. Admission of the capacity comparison

The [earlier capacity-law comparison](../CAPACITY_LOCALIZATION_BALANCE.md#a-predeclared-capacity-law-discriminator)
already supplies `nu_dot=-kappa*L*nu` under a different form/capacity law
with held phase. Its preparation, asymptotics and differentiated EPI result
do not transfer to the present coupled native phase law. Likewise,
[time-varying pure-EPI stability](../TNFR_DIFFUSION_STABILITY_THEOREM.md#time-varying-heterogeneous-capacities)
does not establish the joint phase result below.

The comparison is motivated by explicit additional premises: capacity
transfer uses only incident capacity contrasts, has one reciprocal edge
rule, is linear/additive and regular in that contrast, and has no source.
On the regular C5 these motivate the support-averaging direction. Locality
or covariance alone does not force linearity, a constant rate or absence of
other feedback. The nonnegative rate `kappa` remains free; zero retains the
reference and every positive-rate theorem is for a fixed positive value.
No rate is fitted to a desired waveform.

This is distinct from the [native adaptation policy](../../src/tnfr/dynamics/adaptation.py):
that writer consumes stored pressure and Si, qualifying-call counts, bounds
and a selected subset. A continuous limit, endogenous occurrence rule or
equivalence to that complete policy is not asserted. Redistribution also
does not supply capacity lost in a Silence event. The new mathematical
question is the admissibility, response and local identity of the combined
three-row system, not another proof that averaging can reduce contrast.

## Joint capacity admission and local recovery

<a id="native-capacity-foundation"></a>

This section admits one autonomous capacity completion of the native
relational law and proves its local consequence on the prepared winding-one
unit C5. The capacity completion is supplied under explicit premises. It is
not selected by the nodal identity, installed in the runtime, or identified
with the default gated adaptation policy.

The [native exchange owner](RELATIONAL_EXCHANGE_ADMISSION.md) supplies the
form/phase law, storage and regular phase metric. Its
[local recovery theorem](RELATIONAL_RECOVERY_AND_INTERACTION.md#relational-local-recovery)
already establishes recovery with positive held capacities. The separate
[capacity-law comparison](../CAPACITY_LOCALIZATION_BALANCE.md) already uses
continuous capacity diffusion with fixed phase and a capacity-pressure
channel. The result here couples that admitted capacity law to the native
evolving form/phase rows, with the capacity-pressure channel absent. The new
question is whether recovery survives this enlargement of the retained state.

**Evidence status at drafting:** the following is an analytical conditional
derivation. Prospective independent source controls remain pending. It does
not report evaluated trajectories, a numerical basin, a measured decay rate
or empirical validation.

### Declared complete law and its premises

Let the supplied support be the undirected unit C5, indexed modulo five.
Write its adjacency matrix as \(A\), and set
\[
B=2I-A,\qquad L=B/2,\qquad N=\operatorname{diag}(\nu_i).
\]
The retained state consists of five signed form values \(x_i\), five circular
phases \(\theta_i\), and five strictly positive capacities \(\nu_i\). Work in
one fixed nondimensional structural clock. No graph changes, event requests,
controller state, clipping, history reads or external input are included.

On a regular phase chart define the native source and metric by
\[
\begin{aligned}
g_i(\theta)
 &=\frac1\pi\operatorname{wrap}
   \left(\arg\sum_{j\sim i}e^{i\theta_j}-\theta_i\right),\\
H_i(\theta)
 &=\pi\left|\sum_{j\sim i}e^{i\theta_j}\right|
                  \operatorname{sinc}(\pi g_i)>0,\\
V_\phi(\theta)
 &=\sum_{\{i,j\}\in E}[1-\cos(\theta_j-\theta_i)],\\
H g&=-\nabla V_\phi,\qquad q=Bx .
\end{aligned}
\]
Here \(\operatorname{sinc}(z)=\sin(z)/z\), continuously extended at zero.
Strictly acute principal edge gaps provide the local domain used below;
the prepared winding does not require all node phases to occupy one common
semicircle.

The comparison fixes effective normalized coefficients
\[
e=w=\tfrac12,\qquad \beta=1,\qquad \kappa>0 .
\]
The inherited symbols \(e,w,\beta\) are retained in the algebra below to show
which coefficient enters each term. No additional coefficient is inferred
from their appearance. The complete autonomous law is
\[
\boxed{
\dot x=Np,\quad p=-eLx+wg,\qquad
\dot\theta=\frac w\beta H^{-1}Nq,\qquad
\dot\nu=-\kappa L\nu .
}
\tag{JC1}
\]
Pressure is refreshed from the current form and phase. It is not an
independent held coordinate, nor reconstructed from a measured form rate.
The phase and capacity-contrast pressure coefficients are different objects:
in (JC1), the capacity-pressure and topology-pressure coefficients are zero.
Both native rows consume the full instantaneous \(N\).

The underlying form/phase source is the one admitted by
[dynamics/relational.py](../../src/tnfr/dynamics/relational.py).
That implementation's capacity is held during its selected step; (JC1)
adds a mathematical comparison row rather than changing that execution
contract. Ordinary native pressure normalization is retained. There is no
default capacity-gradient source hidden in \(p\), and no replacement of the
native Arg source by a sine evolution law.

The additional constitutive premise is reciprocal continuous capacity
transfer on the supplied edges:
\[
J_{i\leftarrow j}=\frac\kappa2(\nu_j-\nu_i)
                 =-J_{j\leftarrow i}.
\]
One way to specify this restricted class is to require the same continuous,
additive function of signed capacity contrast at every edge. Additivity and
continuity force \(J(s)=a s\); preservation of the nonnegative capacity cone
requires \(a\ge0\). On C5 write \(a=\kappa/2\). The choice \(\kappa>0\)
excludes the still-admissible held law. Locality, covariance or homogeneity
alone do not establish this entire class or select a numerical \(\kappa\).

This rule has no supplied oscillation period and no event-count clock.
In a dimensional structural clock, \(\kappa\) has inverse-clock units; a
clock conversion must transform it together with the two native rows.
The rule is not a continuous-limit proof for the snapshot-based, gated
capacity adaptation in
[dynamics/adaptation.py](../../src/tnfr/dynamics/adaptation.py).

### Capacity balance, positivity and storage

The symmetric connected C5 Laplacian has \(L\mathbf1=0\). Therefore
\[
\sum_i\nu_i(t)=\sum_i\nu_i(0),\qquad
\bar\nu=\frac15\sum_i\nu_i(0)>0 .
\tag{JC2}
\]
At a capacity minimum, \(-\kappa(L\nu)_i\ge0\), and at a maximum it is
nonpositive. Equivalently, \(e^{-\kappa Lt}\) is a nonnegative stochastic
matrix: for example its exponential series follows from
\(-\kappa L=-\kappa I+(\kappa/2)A\). Consequently
\[
0<\nu_{\min}(0)\le\nu_i(t)\le\nu_{\max}(0)
\quad(t\ge0).
\tag{JC3}
\]
Since \(L\) is symmetric, its spectral decomposition also gives
\[
\begin{aligned}
\|\nu(t)-\bar\nu\mathbf1\|_2
 &\le e^{-\kappa\lambda_1t}
       \|\nu(0)-\bar\nu\mathbf1\|_2,\\
\frac d{dt}\frac12\|\nu-\bar\nu\mathbf1\|_2^2
 &=-\kappa\nu^TL\nu
  =-\frac\kappa2\sum_{\{i,j\}\in E}(\nu_i-\nu_j)^2 ,
\end{aligned}
\tag{JC4}
\]
where \(\lambda_1=1-\cos(2\pi/5)>0\) is the smallest nonzero eigenvalue of
\(L\). This dispersion identity is not a physical energy identification.

Retain the native storage
\[
\mathcal S(x,\theta)=\frac12x^TBx+\beta V_\phi(\theta).
\]
It has no explicit capacity coordinate. Thus capacity evolution creates no
extra \(\dot\nu\) term in its chain rule. With the actual instantaneous
capacity in both native rows,
\[
\begin{aligned}
\dot{\mathcal S}
 &=q^TN(-eLx+wg)
   -\beta(Hg)^T\frac w\beta H^{-1}Nq\\
 &=-\frac e2q^TNq
  =-\frac14\sum_i\nu_i q_i^2\le0 .
\end{aligned}
\tag{JC5}
\]
The final equality uses the fixed \(e=1/2\). Neither a held \(N\) nor a
capacity-dependent storage is needed for this cancellation. Nonincrease
alone does not establish recovery of the phase shape; the full quotient
linearization below supplies that missing implication.

The arithmetic form and phase means need not be conserved:
\[
\dot{\bar x}=\frac15\mathbf1^TNp,\qquad
\dot{\bar\theta}=\frac w{5\beta}\mathbf1^TH^{-1}Nq .
\tag{JC6}
\]
The phase mean here is a local lifted offset, not a global circular
observable. Subtracting either right-hand side from the original dynamics
would change the selected representative; quotient coordinates do not make
those rows vanish.

### The prepared equilibrium family and all retained modes

Put \(\alpha=2\pi/5\), \(c_\alpha=\cos\alpha>0\), and
\(\theta_{*,i}=i\alpha\) modulo \(2\pi\). Oriented principal edge gaps are
\(\alpha\), including the edge crossing the chosen phase lift.
At this reference,
\[
g_*=0,\qquad H_*=2\pi c_\alpha I,\qquad
\nabla^2V_\phi(\theta_*)=c_\alpha B,\qquad
Dg_*=-\frac{B}{2\pi}=-\frac L\pi .
\tag{JC7}
\]
The resultant is nonzero, and the local phase field is smooth.

An equilibrium of (JC1) has \(L\nu=0\), so \(\nu=\bar\nu\mathbf1\).
Strict positivity and invertibility of \(H\) then make
\(\dot\theta=0\) imply \(Bx=0\), hence \(x=c\mathbf1\).
The form row requires \(g=0\). On the acute C5 winding-one sector, vanishing
phase gradient means that consecutive edge sine currents agree.
The sine function is injective on \((-\pi/2,\pi/2)\), so all principal gaps
agree; their winding sum fixes them to \(\alpha\).
Thus the equilibrium family in this sector is exactly
\[
\mathcal M=
\{(c\mathbf1,\theta_*+a\mathbf1,\bar\nu\mathbf1):
       c\in\mathbb R,\ a\in S^1,\ \bar\nu>0\}.
\tag{JC8}
\]
Uniform scalar form coexists with nonconsensus phase geometry. The
organization is prepared on a supplied cycle; its existence is not a
formation theorem.

Choose a real \(5\times4\) matrix \(R\) with
\(R^TR=I\), \(R^T\mathbf1=0\), and let
\(\Pi=RR^T=I-\mathbf1\mathbf1^T/5\). On the conserved mean-capacity leaf,
write
\[
x=c\mathbf1+Ru,\qquad
\theta=\theta_*+a\mathbf1+Rv,\qquad
\nu=\bar\nu\mathbf1+Rh .
\tag{JC9}
\]
The full state has 15 real local coordinates. Fixing only the conserved
capacity mean removes one; quotienting the two common origins removes two
more. The resulting \(z=(u,v,h)\) has 12 coordinates. In particular, the
four capacity contrasts remain free to perturb; equal capacity is not
imposed on the initial state.

Both common-origin shifts are exact symmetries of (JC1), so the quotient
field is autonomous. At (JC8), derivatives of the native rows with respect
to capacity vanish because \(p=q=0\). The capacity row is independent of
form and phase. The quotient Jacobian therefore has an eight-dimensional
native block and a four-dimensional capacity block, with no linear
off-diagonal coupling between these two blocks.

Diagonalize \(R^TLR\). For each of its four modes of eigenvalue \(\lambda>0\),
the corresponding native block and capacity eigenvalue are
\[
J_\lambda=
\begin{pmatrix}
-e\bar\nu\lambda &-w\bar\nu\lambda/\pi\\
w\bar\nu\lambda/(\beta\pi c_\alpha)&0
\end{pmatrix},
\qquad -\kappa\lambda .
\tag{JC10}
\]
The native characteristic polynomial is
\[
s^2+e\bar\nu\lambda s+
  \frac{w^2\bar\nu^2\lambda^2}{\beta\pi^2c_\alpha}.
\tag{JC11}
\]
Its two coefficients after the leading term are strictly positive, so both
roots have negative real part. The two distinct nonzero C5 eigenvalues are
\(1-\cos(2\pi/5)\) and \(1-\cos(4\pi/5)\), each occurring twice.
All 12 quotient modes are therefore strictly stable for each fixed
\(\kappa>0\), \(\bar\nu>0\).

In the full 15-dimensional linearization the remaining three modes are the
two common origins and the conserved capacity mean. They are semisimple
zero modes: the linearized mean rows vanish at the uniform-capacity
reference, while the 12-dimensional transverse block is invertible.
No common offset or empty contrast direction has been discarded by
declaring it stable.

### Local nonlinear recovery and continuation

For every fixed \(\kappa>0\) and \(\bar\nu>0\), sufficiently small joint
form, phase and capacity perturbations of (JC8), on the same mean-capacity
leaf, remain in the acute winding-one chart for all forward time and recover
exponentially to a member of \(\mathcal M\), modulo the two common origins.
The limiting capacity is \(\bar\nu\mathbf1\). This is a conditional local
theorem, not a claim about arbitrary initial states.

Here is a direct nonlinear argument. The positive-capacity regular-chart
field is smooth. In quotient coordinates it has
\[
\dot z=Jz+\mathcal R(z),\qquad
\|\mathcal R(z)\|\le C\|z\|^2
\]
on a sufficiently small neighborhood, where \(J\) is the Hurwitz matrix
just identified. Its positive-definite matrix
\[
P_J=\int_0^\infty e^{J^Tt}e^{Jt}\,dt
\]
is finite and satisfies \(J^TP_J+P_JJ=-I\). Hence
\[
\frac d{dt}(z^TP_Jz)
\le-\|z\|^2+2\|P_J\|C\|z\|^3
\le-\tfrac12\|z\|^2
\]
in a smaller neighborhood. Choose a sufficiently small sublevel ellipsoid
inside the positive-capacity acute chart. It is forward invariant and
gives constants \(M,\sigma>0\) with
\[
\|z(t)\|\le M e^{-\sigma t}\|z(0)\| .
\tag{JC12}
\]
All field denominators remain away from zero there. The capacity hull is
preserved, and the quotient remains in a compact interior set, giving
forward continuation of the local solution.

The two original common-offset velocities are smooth functions of the
quotient and vanish at its equilibrium. Thus
\(|\dot c|+|\dot a|\le C_1\|z\|\) locally. Equation (JC12) makes these
velocities integrable, so \(c(t)\) and the continuously lifted \(a(t)\)
converge to finite \(c_\infty,a_\infty\), with exponential tails.
This also completes continuation of the unquotiented solution.
Their limits need not equal the initial offsets. The winding stays one
because no edge leaves the chosen acute sector.

The proof permits constants and the admission neighborhood to depend on
\(\kappa,\bar\nu\) and the fixed law coefficients. It asserts no uniform
rate or neighborhood as \(\kappa\downarrow0\) or \(\bar\nu\downarrow0\).
It supplies no numerical radius or validated integrator error.

The \(\kappa=0\) boundary is a genuine different target family. At exact
native lock \(x=c\mathbf1,\theta=\theta_*+a\mathbf1\), all positive
capacity profiles leave both native rows zero. For \(\kappa=0\) a
nonuniform profile stays unchanged; for every \(\kappa>0\) it relaxes
according to (JC4). The four capacity contrast eigenvalues tend to zero
as \(\kappa\downarrow0\). Consequently recovery to uniform-capacity
\(\mathcal M\) cannot have a strictly positive rate uniform in this limit.
This does not contradict held-capacity recovery of the same phase shape.

### A causal distinction before any long-time observation

Compare (JC1) with its held-capacity counterpart \(\kappa=0\), starting at
the same complete \((x,\theta,\nu)\) in the regular domain.
Their initial \(p,\dot x,\dot\theta\) agree. Since \(p=-eLx+wg\) has no
capacity-pressure channel, their initial \(\dot p\) also agrees.
Their capacity rates differ by \(-\kappa L\nu\); differentiating the
actual native rows therefore gives
\[
\begin{aligned}
\ddot x^{(\kappa)}(0)-\ddot x^{(0)}(0)
 &=-\kappa\operatorname{diag}(L\nu)\,p,\\
\ddot\theta^{(\kappa)}(0)-\ddot\theta^{(0)}(0)
 &=-\frac{\kappa w}{\beta}
       H^{-1}\operatorname{diag}(L\nu)\,q .
\end{aligned}
\tag{JC13}
\]
The changes in \(H\), \(q\) and \(p\) arising from the initially equal
form/phase velocities cancel in this subtraction. This is a prospective
law-dependent response, not pressure inferred after measuring acceleration.

For an explicit nonzero preparation, let \(e_0=(1,0,0,0,0)^T\), and set
\[
x=c\mathbf1+\varepsilon\Pi e_0,\qquad
\nu=\bar\nu\mathbf1+\eta\Pi e_0,\qquad \theta=\theta_* .
\]
Take small nonzero \(\varepsilon,\eta\), preserving positive capacity and,
when recovery is invoked, its local admission neighborhood. Then
\[
Le_0=(1,-\tfrac12,0,0,-\tfrac12)^T,
\]
and (JC13) specializes to
\[
\begin{aligned}
\Delta\ddot x
 &=\kappa e\varepsilon\eta\,(Le_0)^{\odot2},\\
\Delta\ddot\theta
 &=-\frac{\kappa w\varepsilon\eta}{\beta\pi c_\alpha}
                               (Le_0)^{\odot2}.
\end{aligned}
\tag{JC14}
\]
The symbol \({}^{\odot2}\) denotes componentwise squaring. Both responses
are nonzero, and their means need not vanish. At exact native lock,
in contrast, \(p=q=0\) makes (JC13) zero even while a nonuniform capacity
profile redistributes. Capacity evolution and its observable native response
therefore have distinct state-dependent conditions.

### What this admission establishes and what remains open

The admitted capacity row can coexist with the native exchange storage and
with recovery of a prepared nonconsensus phase organization, retaining all
capacity perturbations. Its autonomous redistribution supplies an explicit
causal law for a previously held coordinate. This advances the complete
model account without selecting that law as necessary or canonical.

The resulting organization is a locally recovered equilibrium geometry,
not sustained nonzero form activity or an internally generated periodic
pulse. No formation mechanism, event occurrence law, thirteen-operator
closure or source ordering is derived. No capacity is created: (JC2)
conserves the C5 total. In particular, redistribution alone cannot replace
capacity removed by a strict Silence (SHA) event. Such events are outside
(JC1), and adding them changes both the law and its return conditions.

The exact local theorem is separate from finite represented arithmetic.
Finite symbolic source controls can check identities, coefficients and
admission at their declared inputs; they do not prove an exact irrational
equilibrium was materialized, global chart invariance for an integrator,
or the nonlinear basin's size. The four foundation prerequisites remain
open until their own scoped closure criteria are met.


## Capacity relaxation versus a finite Coupling action

<a id="native-coupling-realization"></a>

The capacity law admitted above shares the initial direction of one
Coupling (UM) channel. This section asks whether its continuous flow can
produce the finite channel action, even when the elapsed duration is chosen
from the full initial state. The observation is the complete five-node
capacity vector, not its conserved mean. The result classifies this
necessary component of realization; it does not define UM as a diffusion
step or claim that matching capacity realizes the complete operator.

The [earlier capacity owner](../CAPACITY_LOCALIZATION_BALANCE.md#4-canonical-capacity-updates-generally-release-the-static-profile)
already gives the immutable all-target UM capacity map. Its subsequent
comparison holds phase and uses a different pressure mixture on an even
cycle; it does not classify the two C5 spectral bands considered here.
The [general stopping criterion](../STRUCTURAL_OPERATORS.md#regular-stopping-realization)
is reused: agreement of infinitesimal directions need not imply agreement
of a finite action. No generic stopping theorem is claimed as new.

**Prospective evidence declaration:** the derivation below precedes its
independent controls. Evaluated status and immutable attempt receipts belong
to the research program. No trajectory, parameter scan, new execution path
or physical identification is asserted here.

### The retained native state and the precise operator comparison

Retain (JC1), including \(\kappa>0\), the fixed unit C5, and the same
two-channel pressure. Its native-lock manifold is
$$
\mathcal L=
\{x=c\mathbf1,\quad\theta=\theta_*+a\mathbf1,\quad\nu_i>0\}.
$$
This is not the equilibrium family \(\mathcal M\) when capacities differ.
On \(\mathcal L\), \(p=q=g=0\), so both native form/phase rows vanish for
every current capacity. Capacity alone continues to evolve:
$$
\nu(T)=e^{-\kappa TL}\nu(0).
\tag{UR1}
$$
The capacity hull preserves positivity for every finite \(T\ge0\); the
phase chart and winding remain unchanged. Thus using (UR1) retains the
reaction of both native rows, rather than suppressing nonzero reactions.

For the comparison action select the actual
[atomic Coupling stage](../../src/tnfr/operators/network_stage.py), with all
five nodes as targets, target-only phase proposals, capacity synchronization
enabled, functional links disabled, and no grammar replacement. In graph
configuration these choices are UM_BIDIRECTIONAL false, UM_SYNC_VF true and
UM_FUNCTIONAL_LINKS false. Use the live grammar and selected strict activity
policy; these hypotheses do not grant admission by themselves.

The [shared proposal kernel](../../src/tnfr/operators/_coupling_stage_kernel.py)
first selects U3-compatible neighbors from one immutable snapshot. At the
ideal winding-one lock both cycle neighbors are compatible under the default
limit: their principal gaps are \(2\pi/5<\pi/2\). Any configured tightening
must still admit both. The target-only circular phase proposal remains at
the target phase because the two neighbor phasors have resultant
\(2\cos(2\pi/5)e^{i\theta_i}\), with positive real coefficient.
The final merged U3 check remains mandatory.

The kernel's capacity channel reads those two snapshot neighbors and
proposes
$$
\nu_i^+=\nu_i+s\left(\frac{\nu_{i-1}+\nu_{i+1}}2-\nu_i\right),
\qquad U_s\nu=(I-sL)\nu .
\tag{UR2}
$$
Here \(s\) is UM_vf_sync. The
[public factor contract](../../src/tnfr/operators/factor_contracts.py)
admits \(0<s\le1\), and also requires a positive phase-push factor.
The endpoint \(s=0\) below is an explicit analytical extension of (UR2),
or its capacity-disabled comparison, not an admitted zero-gain public UM
invocation. A stationary phase proposal at this preparation is compatible
with a positive configured phase gain.

EPI is not written. Disabling functional links keeps support fixed.
Optional pressure relief still has its own proposal: preparing stored
\(p=0\) makes that write zero in the ideal arithmetic. If a post-stage
pressure refresh is supplied, it must retain the account's two-channel
coefficients, with capacity/topology pressure absent. Ordinary ambient
defaults could introduce capacity-gradient pressure and change the model.

For strict activity admission choose \(|c|\) at or above the selected
UM_MIN_EPI and every \(\nu_i\) at or above UM_MIN_VF, with appropriate
margins if represented states are tested. Their current defaults are 0.05
and 0.01. The [precondition owner](../../src/tnfr/operators/preconditions/__init__.py)
and [Coupling class](../../src/tnfr/operators/coupling.py) also retain the
non-disableable U3 gate, actual neighbor availability and scalar admission.
The stage must preserve the requested UM at every preflight target.
A grammar substitution can select the sequential fallback, which does not
justify the simultaneous matrix (UR2).

Even on this structural preparation, the stage records glyph history,
source-glyph provenance, recognized patterns and stage metadata; configured
monitoring and metrics retain their own effects. No occurrence rule or
evolution of those records is supplied by (UR1). Thus equality of the
capacity components is necessary for any stronger realization claim that
retains that observation, and insufficient for the full registered action.
The exact-real map (UR2) also does not promise bitwise equality between its
matrix expression and the kernel's ordered represented arithmetic.

### Complete finite-time classification

The normalized C5 Laplacian \(L=B/2\) has eigenvalues
$$
0,\qquad
\lambda_-=\frac{5-\sqrt5}{4},\qquad
\lambda_+=\frac{5+\sqrt5}{4},
\tag{UR3}
$$
where each nonzero eigenvalue has multiplicity two. Write the orthogonal
decomposition of the initial vector as
$$
\nu=\bar\nu\mathbf1+\nu_-+\nu_+,\qquad
L\nu_\pm=\lambda_\pm\nu_\pm .
$$
An occupied band means \(\nu_j\ne0\); it may contain any combination of
the two real modes in that eigenspace. Put
$$
s_*=\frac1{\lambda_+}=1-\frac1{\sqrt5}\in(0,1).
$$
For fixed \(\kappa>0\), \(s\in[0,1]\) and finite \(T\ge0\), equality
\(e^{-\kappa TL}\nu=U_s\nu\) has exactly the following cases.

| Initial capacity bands | Gain and allowed duration |
| --- | --- |
| Uniform, \(\nu_-=\nu_+=0\) | Every \(s\in[0,1]\) and every finite \(T\ge0\). |
| Any nonuniform vector, \(s=0\) | Only \(T=0\). This is the analytical endpoint, not zero-gain public execution. |
| Low band only | For every \(0<s\le1\), exactly \(T=-\log(1-s\lambda_-)/(\kappa\lambda_-)>0\). |
| High band only | For \(0<s<s_*\), exactly \(T=-\log(1-s\lambda_+)/(\kappa\lambda_+)>0\). No finite match for \(s\ge s_*\). |
| Both nonzero bands occupied | No finite match for any \(s>0\), even with a state-dependent duration. |

To prove completeness, project the equality onto each occupied eigenspace.
For every such \(j\),
$$
e^{-\kappa T\lambda_j}=1-s\lambda_j .
\tag{UR4}
$$
A finite exponential is strictly positive. A zero right-hand side cannot
match at finite time, and a negative one cannot match at any nonnegative
time. When the right-hand side is positive, (UR4) has the unique displayed
duration. Since \(\lambda_-<1\), its factor stays positive throughout
\(s\in[0,1]\). The high factor is positive below \(s_*\), zero at \(s_*\)
and negative above it.

For two occupied bands with \(0<s<s_*\), consider
$$
f_s(\lambda)=\frac{-\log(1-s\lambda)}{\lambda}
            =\int_0^s\frac{du}{1-u\lambda}.
\tag{UR5}
$$
Its derivative in \(\lambda\) is
\(\int_0^s u(1-u\lambda)^{-2}du>0\).
Thus \(f_s(\lambda_+)>f_s(\lambda_-)\), whereas (UR4) would require both
to equal the same \(\kappa T\). The remaining gains already fail positivity
of the high factor. This is a pointwise contradiction at each two-band
initial vector, so allowing the duration to depend on that vector removes
none of it. No regularity of the chosen stopping rule is needed.

At \(s=s_*\), a high-only vector is mapped to its uniform mean by (UR2).
The continuous capacity flow approaches that mean only as \(T\to\infty\).
This limiting equality is not a finite-duration action. For gains above
\(s_*\), the negative high-band factor is not a negative-capacity claim:
for every \(s\in[0,1]\),
$$
U_s=(1-s)I+\frac s2A
$$
is nonnegative and stochastic, so it preserves the positive capacity hull.
Reversal of a spectral contrast and violation of coordinate positivity are
different statements.

For each nonzero fixed gain there is consequently no exact realization of
(UR2) on a nonempty open subset of the full positive capacity cone. Every
such open subset contains two-band vectors. The one-band exceptions have
empty interior in that cone, even though they include positive vectors and
allow arbitrary orientation within their occupied two-dimensional band.

### Failure persists arbitrarily near uniform capacity

The obstruction does not require a large contrast or departure from the
native lock. Let \(e_0=(1,0,0,0,0)^T\), let
\(\Pi=I-\mathbf1\mathbf1^T/5\), and choose
$$
\nu=\bar\nu\mathbf1+\eta\Pi e_0,\qquad
\bar\nu>0,\quad 0<\eta<\bar\nu/2 .
\tag{UR6}
$$
Its entries are \(\bar\nu+4\eta/5\) at node zero and
\(\bar\nu-\eta/5\) at the other nodes. All are positive, and \(\eta\)
can be arbitrarily small. When the strict activity policy is included,
take \(\bar\nu\) above its capacity threshold and reduce \(\eta\) further
to retain that margin; choose the common form independently above its
selected magnitude threshold.

Let \(c_\pm\) denote the real cosine vectors with components
\(\cos(2\pi ki/5)\), with \(k=1\) for the low band and \(k=2\) for the
high band. The standard five-cycle Fourier identities give
$$
\Pi e_0=\frac25(c_-+c_+),\qquad
\nu_\pm=\frac{2\eta}{5}c_\pm,\qquad
\|\nu_\pm\|_2^2=\frac{2\eta^2}{5}>0 .
\tag{UR7}
$$
Thus every positive amplitude in (UR6) occupies both bands. The preceding
classification excludes a finite match for every \(s>0\) despite proximity
to the uniform-capacity equilibrium family. Both maps preserve the same
mean \(\bar\nu\); observing only that mean would conceal this distinction.

### Near-identity agreement, time calibration and its remaining error

Fix a capacity vector while \(s\downarrow0\). Write \(a=\kappa T\) and
compare the full capacity outputs using their Euclidean norm. At the
natural first-order calibration \(a=s\),
$$
E(s,s):=e^{-sL}\nu-(I-sL)\nu
       =\frac{s^2}{2}L^2\nu+O(s^3).
\tag{UR8}
$$
For a direct finite bound, the scalar remainder satisfies
\(0\le e^{-y}-1+y\le y^2/2\) for \(y\ge0\), by its integral remainder.
Orthogonal spectral decomposition then gives
$$
\|E(s,s)\|_2
 \le\frac{s^2\lambda_+^2}{2}
       \|\nu-\bar\nu\mathbf1\|_2,\qquad s\ge0 .
\tag{UR9}
$$
This is an ideal comparison bound, not a time-step or floating-point
certificate for the runtime.

A second-order time correction \(a=s+b s^2+o(s^2)\) gives
$$
\frac{E(s,a)}{s^2}
 \longrightarrow
 \left(\frac12L^2-bL\right)\nu
 =\sum_{j\in\{-,+\}}\lambda_j(\lambda_j/2-b)\nu_j .
\tag{UR10}
$$
For one occupied band, \(b=\lambda_j/2\) cancels this term, consistently
with the exact single-band duration. For two occupied bands the same
coefficient \(b\) cannot cancel both.

More quantitatively, set
$$
W_j=\lambda_j^2\|\nu_j\|_2^2>0 .
$$
The square of the leading defect in (UR10) is
\(\sum_j W_j(\lambda_j/2-b)^2\).
Completing the square gives the unique minimizing time coefficient and
its strictly positive remaining norm:
$$
b_*=\frac{W_-\lambda_-+W_+\lambda_+}{2(W_-+W_+)},
\qquad
C(\nu)=\frac{\lambda_+-\lambda_-}{2}
       \sqrt{\frac{W_-W_+}{W_-+W_+}}>0 .
\tag{UR11}
$$

In fact this constant is optimal over all nonnegative durations, without
assuming a differentiable stopping rule:
$$
\inf_{T\ge0}\|e^{-\kappa TL}\nu-(I-sL)\nu\|_2
 =C(\nu)s^2+o(s^2)
 \quad(s\downarrow0)
\tag{UR12}
$$
for each fixed two-band vector \(\nu\). To justify the lower bound as well
as the formal expansion, first use the trial
\(a=s+b_*s^2\), positive for small \(s\), to obtain the upper bound.
Choose any sequence of approximate minimizing durations whose errors are
within \(o(s^2)\) of the infimum. Their errors are therefore \(O(s^2)\).
Projection onto either fixed occupied band yields
$$
e^{-a\lambda_j}=1-s\lambda_j+O(s^2).
$$
The right-hand side tends to one, so \(a\to0\). Taking its logarithm
then gives \(a=s+O(s^2)\). Thus
\(b_s=(a-s)/s^2\) is bounded. Along any convergent subsequence of these
bounded coefficients, the expansion (UR10) is uniform and its limiting
norm is at least \(C(\nu)\) by (UR11). If a smaller lower limit existed,
one could choose such a subsequence realizing it, a contradiction.
This proves (UR12), together with the trial upper bound.

This argument includes durations selected from the whole initial state.
For a fixed two-band vector no such timing choice achieves \(o(s^2)\)
capacity error. The coefficient is not uniform as an occupied band
vanishes or as the whole contrast amplitude tends to zero. In the uniform
case the error is exactly zero; in a single band the calibrated finite
match already classifies the exception.

For the arbitrarily small preparation (UR6), (UR7) reduces (UR11) to
$$
b_*=\frac56,\qquad C(\nu)=\frac{|\eta|\sqrt{30}}{24}.
\tag{UR13}
$$
These are conditional coefficients of an ideal local gain expansion,
not observed precision thresholds or a new choice of UM gain.

### Causal conclusion and boundaries

The capacity comparison passes a first-order direction test and fails
finite realization on generic positive C5 capacity states. Two independent
spatial relaxation rates are enough to distinguish the supplied continuous
constitutive law from the registered finite capacity channel. Adjusting a
single elapsed time cannot remove that distinction. This is more specific
than saying that jumps and flows have different names.

The conclusion does not forbid Coupling as a primitive discrete mechanism,
exclude another constitutive generator, or derive an autonomous event
selector. It does not assert that every operator must arise from this
particular diffusion. Single-band equality and the approximation bound
are admissible mathematical exceptions; neither settles the remaining
registered writes, history, grammar, occurrence or donor reaction in a
different proposed realization. All four foundational readiness conditions
remain open, and the research program must reassess the next dependency
rather than automatically extending this example.

## Joint admission decision for the provisional foundation

<a id="native-foundation-admission"></a>

**Decision: adopt JC1 provisionally as a mathematical account of a prepared,
isolated C5 organization, its local recovery and its conditional response.**
Keep the held-capacity native law as its implemented reference and retained
alternative. Do not identify the two execution contracts. This decision
accepts a coherent complete model on an explicit domain; it does not declare
its premises uniquely necessary, its graph a universal elementary NFR, or
its observations a physical identification.

This is an admission review of existing definitions, proofs, countermodels
and retained evidence. It introduces no new trajectory, scientific control,
operator invocation or parameter search. The two joint-capacity and Coupling
sections above own their derivations and frozen controls. The
[law-admission criterion](../DIAGNOSTIC_AND_GRAMMAR_SCOPE.md#justified-law-admission)
and [four foundation criteria](../RESEARCH_PROGRAM.md#foundational-pillars)
govern this decision. The current research task remains in the program.

### The claim being admitted

The object is the full labeled five-node configuration on the supplied unit
cycle. Its nonuniform phase organization is prepared near the winding-one
equilibrium family, with signed real form, circular phase and strictly
positive capacities. Its intended capability here is retention of that
organization and a predictable response to sufficiently small changes of
the full initial state. Initialization is an input to this claim, not an
event selected by the dynamics.

For this claim the selected complete law is JC1, with `e=w=1/2`, `beta=1`
and a fixed positive `kappa` supplied before predicting a response. The
support and structural clock are fixed, with no inputs, clipping, support
events, registered actions or consumed histories. Pressure is refreshed
mathematically from the current form and phase. Both native rows and the
capacity row evolve in the same declared clock.

We select the direct nodewise-exchange route for the phase law. Joint
Dirichlet/cosine storage, its positive relative weight and cancellation at
each nodal form/phase work port are independent constitutive hypotheses.
Continuity on the regular phase chart then fixes the reciprocal phase row,
including points where phase pressure is zero. The
[capacity-separability](RELATIONAL_EXCHANGE_ADMISSION.md#capacity-separable-exchange)
and [uniform primitive-locality](RELATIONAL_EXCHANGE_ADMISSION.md#primitive-locality-exchange-selection)
theorems offer other sufficient premise sets; they are not silently combined
into a claim that locality or the nodal product alone selects the law.

This choice has a structural interpretation independent of a desired
waveform: the specified two storage channels exchange work at the same
nodal ports, and the declared form loss accounts for the remaining change.
It remains a hypothesis about that accounting. The reference has not been
selected by fitting a sustained pulse, a diagnostic maximum or a physical
constant. Its successful consequences justify using it for this scoped
investigation, not removing its independent premises.

### Premise, alternative and capability decisions

The statuses below distinguish definitions and model restrictions from
independent constitutive hypotheses, their derived consequences, numerical
methods and supplied interventions. An alternative can remain mathematically
viable without being the active law. Excluding it from this model is not a
proof that TNFR excludes it universally.

| Consumed premise or mechanism | Logical status | Admission and existing evidence | Retained alternative and consequence |
| --- | --- | --- | --- |
| Signed form, circular phase and positive capacity | Declared coordinates and domain | Adopt the full joint state on the regular positive-capacity neighborhood in JC7-JC12; [state/chart distinctions](../FUNDAMENTAL_THEORY.md#24-physical-concepts-mathematical-types-and-implementation) remain applicable. | The engine's larger nonnegative-capacity domain is meaningful, but this recovery theorem does not cover its zero boundary. A scalar form reader or a diagnostic tuple has not been proved sufficient. |
| Unit C5, labels and prepared winding | Supplied support and initialization | Adopt as a tractable organized object with an independently stated identity. C5 is minimal only within the nonzero strictly acute simple-cycle twist class. | Other supports and supplied preparations are retained. A ring drawn in a figure does not supply physical geometry, graph birth or a universally elementary constituent. |
| `p=-eLx+w*g(theta)` | Independent constitutive pressure hypothesis; derived reader after that choice | Adopt this two-channel map, with fresh current-state pressure, as used in JC1 and the [native source owner](RELATIONAL_EXCHANGE_ADMISSION.md#reuse-without-changing-the-complete-law). It is specified before the response. | Held pressure, an independently evolved pressure and nonzero capacity/topology pressure channels are different models. Substituting one changes closure, balances and response. |
| Joint storage and nodewise work exchange | Independent constitutive hypotheses | Adopt the [specified storage and nodal cancellation](RELATIONAL_EXCHANGE_ADMISSION.md#1-state-inherited-geometry-and-the-independent-premise), with no physical-energy interpretation. | Mere total passivity allows additional phase loss and nonlinear exchange. A convenient loss inequality does not select the exact cancellation allocation. |
| Reciprocal phase row and common-phase convention | Conditional derived law | Adopt the continuous regular-chart completion following the chosen nodal exchange premise. Its zero-capacity phase-freezing extension is stronger than the nodal form identity. | Global balance alone leaves power-null alternatives and common-phase motion. Their domains and stronger locality exclusions must be checked separately. |
| `nu_dot=-kappa*L*nu` | Independent reciprocal, source-free capacity-transport hypothesis | Adopt JC1 for this C5 domain. Its capacity hull, conserved total, storage identity and joint local recovery are derived consequences, not extra fitted outcomes. | Held capacity remains a closed alternative; JC13 distinguishes its response. Native gated adaptation is a separate per-call policy, and redistribution does not replace capacity lost through Silence (SHA). |
| Coefficients and structural clock | Supplied model data and units | Retain the fixed effective pressure weights, storage ratio and positive capacity-transfer rate. Transform every row under a clock change. | The [held two-row coefficient audit](RELATIONAL_RESPONSE_IDENTIFICATION.md#coefficient-synergy-audit) leaves response-relevant freedom. Its parameter count cannot simply be transferred to JC1, which additionally consumes a capacity-transfer rate. No absolute clock or universal coefficient is selected here. |
| Pressure, phase metric, storage, winding and other read-outs | Derived observations on their domains | Use them to report the chosen state and response. Smooth local continuation follows from the actual full field and JC12, not from their names. | Equal observations do not establish equal predictive states. Unavailable readings are not zero, and conserved total capacity alone does not describe redistribution. |
| Common origins and fixed capacity-mean leaf | Exact continuous symmetries and retained invariant data | Use the 12-coordinate relative description only with the positive mean capacity retained as leaf data; reconstruct the two mean rows for absolute output. | Mean capacity is not a disposable gauge. Event activity thresholds and histories need information absent from this continuous quotient. |
| Phase identity, recovery and activity | Declared identity plus conditional dynamical results | Adopt local recovery of the nonuniform phase shape and all-forward regular continuation within the proved neighborhood. Exact periodicity is not required for this identity. | Preparation, acquisition, sustained internal motion, global attraction and a numerical basin are distinct claims. The theorem does not establish them by calling the equilibrium an organization. |
| Registered structural actions | Supplied interventions under their own contracts | No registered invocation is needed for the event-free prediction. Retain the [operator causal-role distinctions](../STRUCTURAL_OPERATORS.md#operator-causal-role) when an action is requested. | Continuous capacity exchange does not generally realize the finite UM component; its special matches do not supply history, grammar, full secondary writes or autonomous occurrence. The thirteen names neither prove nor disprove generative completeness. |
| Field evaluation, numerical execution and adaptation | Implementation and numerical policies | The [relational executor](../../src/tnfr/dynamics/relational.py) implements the held-capacity reference with admitted Euler proposals. JC1 remains a mathematical completion. | Changing capacity between calls is not a certified joint JC1 integration. The [adaptation policy](../../src/tnfr/dynamics/adaptation.py) consumes stored gates and qualifying-call counts, not an automatically inherited continuous clock. |

### Why the conditional adoption is substantive

The [joint proof](#native-capacity-foundation) establishes a smooth,
autonomous full-state field on its admitted domain, preservation of positive
capacity, a conserved capacity mean and a compatible storage loss. Its
15-coordinate linearization retains every capacity perturbation. After fixing
that mean and removing the two common origins, all 12 relative modes are
strictly stable. The nonlinear continuation argument supplies a sufficiently
small forward-invariant neighborhood and exponential recovery. Its actual
common offsets converge; they are not incorrectly declared conserved.

Consequently the state and complete model data determine a unique admitted
future there. This is more than a stable-looking picture or a list of state
variables. It establishes a conditional predictive model and a recoverable
organization without an external pulse schedule. The neighborhood and rate
depend on the declared parameters; there is no numerical admission radius,
uniform positive rate as `kappa` or mean capacity approaches zero, or new
validated integrator certificate. No event selector is required to make this
event-free claim complete.

Sufficiency is relative to the law and the requested output. The 15 local
coordinates do not establish a universally minimal NFR state. The
12-coordinate quotient is not three effective scalars, and fixing the
capacity mean does not make it irrelevant: it affects response rates. An
absolute form or phase output retains its origins. For registered actions,
even an otherwise exact continuous symmetry may fail to preserve admission:
Coupling uses absolute form magnitude thresholds and live history/context.
Thus neither that quotient nor raw `(x,theta,nu)` alone is the complete
ordinary hybrid-runtime state.

### What the alternatives actually exclude

The provisional choice survives as a coherent model; several stronger
selection claims do not survive the retained countermodels.

- The [passive phase-loss family](RELATIONAL_EXCHANGE_ADMISSION.md#relational-passive-loss-completion)
  keeps the native form pressure, declared storage, local information and
  capacity conditions while adding phase dissipation. It can change damping
  and form acceleration. Passivity, recovery and symmetry therefore do not
  by themselves select zero additional phase loss.
- The [nonlinear passive completion](RELATIONAL_EXCHANGE_ADMISSION.md#relational-nonlinear-passive-completion)
  retains own-capacity dependence, primitive one-hop information, signed
  symmetries, equilibria and the same held-capacity equilibrium Jacobian.
  Its nonlinear response differs. It satisfies a loss bound, not the exact
  reference loss; even matching a tangent cannot silently replace that
  constitutive premise. Its amplitude expansion is not a statement that
  finite-state temporal derivatives agree to the same order.
- The [capacity-mediated exchange alternative](RELATIONAL_EXCHANGE_ADMISSION.md#capacity-mediated-exchange-counterexample)
  retains the native form row and exact total loss but relaxes independent
  own-capacity dependence. It consumes two primitive neighborhoods on general
  graphs. Its fixed-K3 counterexample constrains weaker selection claims;
  it does not refute the theorem imposing one uniform primitive-neighborhood
  law across every admitted graph.
- The [normalized-sine comparison](SINE_CONSTITUTIVE_INFORMATION.md#global-closure-pressure-comparison)
  changes pressure and phase mobility. It remains a useful distinct law.
  Its formation, pulse, memory and interaction results cannot be attached to
  JC1 merely because both models use form and phase or share a storage sign.
- The ordinary hybrid runtime and native adaptation remain viable execution
  policies under their own contracts. The finite UM obstruction shows that
  a matching initial direction does not identify one of their actions with
  elapsed JC1 flow. The conclusion concerns this proposed realization, not
  the impossibility of every continuous realization of every operator.

The chosen nodewise cancellation also fixes the representative of common
phase motion. Adding a common phase velocity may preserve total phase work
while changing its nodal allocation. Such a change requires a newly declared
observation/clock convention and law; it must not enter as an unnoticed
implementation convenience. These distinctions explain the constitutive
freedom rather than trying to remove it through terminology.

### Formation and interaction retain their actual evidence

The present adoption does not turn preparation into formation. The existing
[fixed-cycle resultant obstruction](RELATIONAL_DOMAIN_AND_CAPTURE.md#relational-cycle-resultant-obstruction)
separates C5 phase consensus from its acute winding-one twist along every
continuous path with nonzero local resultants: their derived skip windings
differ. This geometric statement is independent of the capacity law.
Allowing JC1's positive capacities to change therefore does not remove it.
An autonomous acquisition claim between those states needs a justified
change of support, domain or mechanism; a larger perturbation or a relaxed
acute cutoff alone does not settle that obstruction.

This is not a claim that native formation and interaction are absent from
the repository. The [retained formation controls](RELATIONAL_FORMATION_CONTROLS.md)
join a certified winding-zero transit to protected capture on a supplied
two-ring support with unit held capacities and exact symmetry. The
[joined-region interaction](RELATIONAL_RECOVERY_AND_INTERACTION.md#relational-region-interaction)
already gives recovery and a transmitted response under the held-capacity
native law. Those are affirmative results on their actual preparations.
They do not establish arbitrary initial acquisition, JC1 interaction with
unequal changing capacities, or spontaneous creation of the joining support.

Once regions are connected, relative regional origins become dynamical
information and the port degrees, pressure normalization and phase metric
change. Independent isolated-ring descriptions cannot simply be placed side
by side and called a complete interacting model. The earlier interaction
owner already accounts for these effects with held capacity; that result
should be reused at its scope rather than repeated or transferred by name.

### Three different meanings of capacity composition

Three statements must remain separate when this account is extended.

1. Additivity of the **phase response** in independent capacity vectors,
   at fixed form, phase and support, is a sufficient premise in the phase-row
   selection theorem. It does not specify a capacity-transport law.
2. Conservation of **a sum of capacities** is a consequence of a chosen
   transport generator and support measure. JC1 preserves the ordinary sum
   on C5. This is not a declaration that capacity is a universal additive
   substance, energy, or a conserved quantity under every registered event.
3. An **effective regional capacity** belongs to a proved reduction and its
   retained boundary data. The [scale owner](../TNFR_SCALE_GEOMETRY_AND_BRIDGE.md#1-pure-epi-coarse-graining)
   already obtains coefficients depending on boundary conductance and
   degree/capacity sums in its reversible pure-EPI scope. They are not
   generally an ordinary sum, nor a closure of the full JC1 dynamics.

These are different mathematical obligations despite sharing the word
capacity. Confusing them would make a phase-selection premise appear to
justify conservation or coarse closure that it does not supply.

### Joint foundation verdict and the interaction boundary

For the admitted isolated prediction, the causal, state and identity accounts
are mutually compatible: every consumed row is specified independently of
its evaluated response; derived readers do not replace the retained state;
the organization has a local continuation and recovery argument. The
alternatives explain which extra assumptions are doing work. This warrants
provisional adoption for the stated capability without a uniqueness claim.

It does not close the four broader readiness requirements. P1 still needs
an admitted causal account for any extension actually consumed by a later
claim; P2 must retain the boundary and observation information for it; P3
requires formation or joint retention whenever claimed; and P4 must assess
those dependencies together against the intended next capability. These
requirements do not demand all thirteen actions in every model, universal
minimality, exact periodicity or uniqueness of every coefficient. Equally,
a local success cannot waive a missing premise of an interaction or physical
claim. The readiness record therefore stays open.

The consequential unresolved interface is capacity transport on irregular
support when organized regions are joined. On unit C5, the reciprocal
edge-transfer expression `-(kappa/2)*B*nu` equals degree-normalized averaging
`-kappa*D^(-1)*B*nu`, because `D=2I`. At degree-three contact ports those
expressions are different. On fixed reciprocal support the former preserves
the ordinary total, whereas the latter preserves the degree-weighted total.
This distinction follows from the two candidate generators; it is not a new
evaluated contact response or a selection made by the C5 controls.

Retaining JC1's specified reciprocal edge flux favors the first expression.
Extending that premise beyond C5 is an explicit model-family decision, not
an automatic consequence of recovery. Conversely replacing `B/2` by a
degree-normalized Laplacian because it resembles a software averaging rule
silently changes the transfer premise. The additive measure, edge law and
meaning of capacity under composition must be justified together, along with
the native pressure/phase geometry and retained port state. Fixed support
conservation also does not provide the balance across an edge-creation event.

Admitting this boundary is the next prerequisite for an interaction claim
under the dynamic-capacity account. A joined support may first be supplied
and then held fixed; that does not derive the event that created it. The
program specifies the bounded decision and its acceptance conditions. No
interaction run, new generator, support event or physical mapping is
activated by this review alone.
